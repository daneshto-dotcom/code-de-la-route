# LEGACY OF THE REALM: FOUNDING REALM
## Simulation Core v1

A persistent medieval realm simulation — the engine that powers everything.

---

## Quick Start

```bash
# Run all tests (100 tests across 9 suites)
npx ts-node --transpile-only tests/simulation.test.ts

# Seed a new realm and display status
npx ts-node --transpile-only src/main.ts seed
```

---

## Architecture

### Layer Separation (Anti-Corruption Boundaries)

```
┌─────────────────────────────────────────────────┐
│  UI / PRESENTATION  (Godot client — NOT HERE)   │ ← Renders state, sends input
├─────────────────────────────────────────────────┤
│  NETWORKING         (WebSocket — NOT HERE YET)  │ ← Serializes, authenticates
├─────────────────────────────────────────────────┤
│  SIMULATION         (THIS CODEBASE)             │ ← All game logic lives here
├─────────────────────────────────────────────────┤
│  PERSISTENCE        (src/persistence/)          │ ← Reads/writes state
└─────────────────────────────────────────────────┘
```

The simulation layer has **zero** dependencies on rendering, networking, or specific databases.
It exposes a command interface that any transport layer can wrap.

### Module Communication

Modules **never** call each other directly. All communication flows through the **Event Bus**.

```
TIME ──publishes──▶ DayPhaseChanged ──▶ ECONOMY (resets daily counters)
                                    ──▶ QUEST   (refreshes quest board)
                                    ──▶ NPC     (updates schedules)

ECONOMY ──publishes──▶ TransactionCompleted ──▶ REPUTATION (checks guild standing)
                                             ──▶ CHRONICLE  (logs if notable)

CHARACTER ──publishes──▶ CharacterDied ──▶ HOUSEHOLD (processes inheritance)
                                       ──▶ CHRONICLE (generates obituary)
```

---

## Folder Structure

```
founding-realm/
├── src/
│   ├── types/index.ts            # All enums, interfaces, branded type IDs
│   ├── core/
│   │   ├── events.ts             # Typed event bus with logging
│   │   └── simulation.ts         # GameState, orchestrator, high-level actions
│   ├── modules/
│   │   ├── time/index.ts         # Day/night, seasons, years, aging
│   │   ├── economy/index.ts      # Transaction pipeline, money supply, inflation
│   │   ├── character/index.ts    # Character lifecycle, ranks, death
│   │   ├── household/index.ts    # Dynasty, inheritance, Heritage Bonus
│   │   ├── reputation/index.ts   # 4-track reputation, threshold titles
│   │   ├── settlement/index.ts   # Land claims, structures, tier growth, decay
│   │   ├── guild/index.ts        # Charter, membership, dues, dissolution
│   │   ├── quest/index.ts        # Templates, procedural generation, rewards
│   │   ├── chronicle/index.ts    # Auto-generated history, year sealing
│   │   └── world/index.ts        # 17 zones with safety/ring classification
│   ├── persistence/index.ts      # Abstract interface + JSON file adapter
│   ├── seed/index.ts             # 12 founding characters with economic activity
│   ├── main.ts                   # Entry point
│   └── global.d.ts               # Node.js type declarations
├── tests/
│   └── simulation.test.ts        # 100 tests across 9 suites
├── save/                         # Persisted realm state (auto-created)
└── tsconfig.json
```

---

## Domain Modules

| Module | Owns | Key Functions |
|--------|------|---------------|
| **TIME** | Day/night, seasons, years, aging | `advanceTick()`, `fastForwardDays()`, `getLifeStage()` |
| **ECONOMY** | Currency, transactions, inflation | `processTransaction()`, `computeEconomySnapshot()` |
| **CHARACTER** | Character state, class, rank | `createCharacter()`, `advanceRank()`, `killCharacter()` |
| **HOUSEHOLD** | Dynasty, treasury, heirlooms | `processInheritance()`, `calculateHeritageBonus()` |
| **REPUTATION** | 4 tracks, titles, thresholds | `modifyReputation()`, `getHighestTitle()` |
| **SETTLEMENT** | Land, structures, tier growth | `foundSettlement()`, `buildStructure()`, `reviewSettlementTier()` |
| **GUILD** | Charter, members, dissolution | `charterGuild()`, `addMember()`, `checkDissolution()` |
| **QUEST** | Templates, generation, rewards | `generateDailyQuests()`, `completeQuest()` |
| **CHRONICLE** | Permanent history, year sealing | `addEntry()`, `sealYear()`, `wireChronicleListeners()` |
| **WORLD** | 17 zones, safety, start zones | `getZone()`, `getBuildableZones()`, `getStartZone()` |

---

## Key Design Decisions

### Branded Type IDs
All entity IDs use TypeScript branded types (`CharacterId`, `HouseholdId`, etc.) to prevent
accidental mixing of IDs across entity types at compile time.

### Event Sourcing for Economy
Every transaction is logged immutably. Current balances are derived from the log.
This provides a full audit trail and enables replay/debugging.

### Immutable Chronicle
Once a Chronicle entry is created, it is never modified or deleted.
Year-sealed entries are truly permanent — the game's promise that "the world remembers."

### Soft Deletes
No entity is ever deleted. Dead characters, dissolved guilds, and ruined settlements
remain in the data for Registry and Chronicle reference.

### Heritage Bonus
When a character dies, their heir starts with advantages proportional to the
household's accumulated legacy — but capped to prevent runaway dynasties.

---

## Extension Points

### Adding a Networking Layer
```typescript
// The simulation exposes these functions — wrap them with WebSocket handlers:
import { spawnCharacter, performLabor, buyFood, earnReputation } from "./core/simulation";

// Server receives client message → validates auth → calls simulation function → broadcasts result
websocket.on("action:labor", (session, data) => {
  const charId = getCharacterForSession(session);
  const success = performLabor(gameState, eventBus, charId, data.wage);
  websocket.send(session, { type: "labor:result", success });
});
```

### Swapping Persistence
```typescript
// Replace JSONPersistence with PostgresPersistence:
import { PersistenceAdapter } from "./persistence";

class PostgresPersistence implements PersistenceAdapter {
  async save(state: GameState): Promise<void> { /* INSERT/UPDATE to PG */ }
  async load(): Promise<GameState | null> { /* SELECT from PG */ }
}
```

### Adding a New Module
1. Create `src/modules/combat/index.ts`
2. Define its state, functions, and events in `src/types/index.ts` and `src/core/events.ts`
3. Wire it into `src/core/simulation.ts` (subscribe to events, add to GameState)
4. Add tests in `tests/`
5. The module communicates ONLY through the event bus — never imports other modules directly

### Connecting to Godot
The simulation runs as a headless server process. The Godot client connects via WebSocket,
sends player actions as commands, and receives authoritative state updates. The client
never decides game outcomes — it only renders what the server tells it.

---

## Test Coverage

| Suite | Tests | What's Covered |
|-------|-------|----------------|
| Time | 26 | Day phases, seasons, year rollover, aging, life stages, event firing |
| Economy | 12 | Transactions, validation, insufficient funds, SYSTEM injection, velocity, inflation |
| Reputation | 11 | Score changes, clamping 0–999, threshold crossing, title grants, highest title |
| Household | 16 | Creation, inheritance (50% rule), Heritage Bonus, full dynasty cycle |
| Settlement | 5 | Founding, population, tier advancement, Chronicle integration |
| Guild | 4 | Charter, status, membership, event firing |
| Chronicle | 6 | Entry creation, multi-type entries, year sealing, event wiring |
| Seed Scenario | 18 | Full 12-character realm with economy, settlements, guilds, time advancement |
| Quest | 5 | Generation, acceptance, completion, rewards, event firing |
| **Total** | **100** | |

---

## The Persistence Promise

> No player's legacy is ever erased.
> The game scales by growing, not by resetting.
> The v1 server is not a beta — it is the first chapter of a story that continues forever.

*A Realm to Enter, A Legacy to Forge.*
