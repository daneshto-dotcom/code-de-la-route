// ═══════════════════════════════════════════════════════════════════
// SEED DATA — Populates a new realm with founding characters.
// Run this to create a playable starting state.
// ═══════════════════════════════════════════════════════════════════

import {
  CharacterClass, ReputationTrack, ZoneId, GuildType,
} from "../types";
import { EventBus } from "../core/events";
import {
  GameState, createGameState, spawnCharacter, performLabor,
  earnReputation, doFoundSettlement, doCharterGuild,
  buyFood, payTax, doCompleteQuest, advanceDays, getEconomySnapshot,
} from "../core/simulation";
import { addResident, buildStructure } from "../modules/settlement";
import { addMember } from "../modules/guild";

export interface SeedResult {
  state: GameState;
  bus: EventBus;
  characterIds: Record<string, string>;
}

export function seedRealm(): SeedResult {
  const { state, bus } = createGameState(1601);
  const ids: Record<string, string> = {};

  // ── Founding Characters ────────────────────────────────────────
  // A diverse founding population representing all classes
  ids.elara = spawnCharacter(state, bus, "Elara Renard", CharacterClass.PEASANT, "House Renard");
  ids.tomas = spawnCharacter(state, bus, "Tomas Holt", CharacterClass.PEASANT, "House Holt");
  ids.agnes = spawnCharacter(state, bus, "Agnes Duval", CharacterClass.NOBLE, "House Duval");
  ids.margaux = spawnCharacter(state, bus, "Margaux Varenne", CharacterClass.MERCHANT, "House Varenne");
  ids.brennan = spawnCharacter(state, bus, "Brennan Ashford", CharacterClass.KNIGHT, "House Ashford");
  ids.cole = spawnCharacter(state, bus, "Cole the Smith", CharacterClass.ARTISAN, "House Cole");
  ids.lira = spawnCharacter(state, bus, "Lira Shadefoot", CharacterClass.ROGUE, "House Shade");
  ids.aldric = spawnCharacter(state, bus, "Brother Aldric", CharacterClass.MONK, "House Aldric");
  ids.wren = spawnCharacter(state, bus, "Wren Thornwood", CharacterClass.RANGER, "House Thornwood");
  ids.pip = spawnCharacter(state, bus, "Pip the Swift", CharacterClass.ADVENTURER, "House Swift");
  ids.maren = spawnCharacter(state, bus, "Old Maren", CharacterClass.PEASANT, "House Maren");
  ids.dael = spawnCharacter(state, bus, "Captain Dael", CharacterClass.KNIGHT, "House Dael");

  console.log(`  ✓ ${state.characters.size} founding characters created`);

  // ── Found Settlements ──────────────────────────────────────────
  const ashwoodId = doFoundSettlement(state, bus, "Ashwood", "zone_ashwood" as ZoneId, ids.elara as any);
  const millbrookId = doFoundSettlement(state, bus, "Millbrook", "zone_millbrook" as ZoneId, ids.tomas as any);

  // Add residents
  if (ashwoodId) {
    let stl = state.settlements.get(ashwoodId)!;
    for (const name of [ids.maren, ids.cole, ids.aldric, ids.pip]) {
      stl = addResident(stl, name as any);
    }
    stl = buildStructure(stl, "Well", state.clock.tickCount, bus);
    stl = buildStructure(stl, "Workshop", state.clock.tickCount, bus);
    stl = buildStructure(stl, "Campfire Ring", state.clock.tickCount, bus);
    state.settlements.set(ashwoodId, stl);
  }

  if (millbrookId) {
    let stl = state.settlements.get(millbrookId)!;
    stl = addResident(stl, ids.dael as any);
    stl = buildStructure(stl, "Guard Post", state.clock.tickCount, bus);
    state.settlements.set(millbrookId, stl);
  }

  console.log(`  ✓ ${state.settlements.size} settlements founded`);

  // ── Charter Guilds ─────────────────────────────────────────────
  const smithGuildId = doCharterGuild(state, bus, "Blacksmith Guild", "TRADE", ids.cole as any);
  if (smithGuildId) {
    let guild = state.guilds.get(smithGuildId)!;
    guild = addMember(guild, ids.elara as any, state.clock.tickCount, bus);
    guild = addMember(guild, ids.tomas as any, state.clock.tickCount, bus);
    state.guilds.set(smithGuildId, guild);
  }

  const gateOrderId = doCharterGuild(state, bus, "Order of the Gate", "MILITARY", ids.brennan as any);
  if (gateOrderId) {
    let guild = state.guilds.get(gateOrderId)!;
    guild = addMember(guild, ids.dael as any, state.clock.tickCount, bus);
    guild = addMember(guild, ids.pip as any, state.clock.tickCount, bus);
    state.guilds.set(gateOrderId, guild);
  }

  console.log(`  ✓ ${state.guilds.size} guilds chartered`);

  // ── Simulate Early Economic Activity ───────────────────────────
  // Peasants do labor
  for (const peasantId of [ids.elara, ids.tomas, ids.maren]) {
    for (let i = 0; i < 5; i++) {
      performLabor(state, bus, peasantId as any, 8 + Math.floor(Math.random() * 8));
    }
  }

  // Knight patrols
  for (let i = 0; i < 3; i++) {
    performLabor(state, bus, ids.brennan as any, 15);
    earnReputation(state, bus, ids.brennan as any, ReputationTrack.HONOR, 5);
  }

  // Merchant trades
  performLabor(state, bus, ids.margaux as any, 25);
  performLabor(state, bus, ids.margaux as any, 30);
  earnReputation(state, bus, ids.margaux as any, ReputationTrack.GUILD, 8);

  // Scholar researches
  performLabor(state, bus, ids.aldric as any, 10);
  earnReputation(state, bus, ids.aldric as any, ReputationTrack.CROWN, 5);

  // Ranger scouts
  performLabor(state, bus, ids.wren as any, 12);
  earnReputation(state, bus, ids.wren as any, ReputationTrack.HONOR, 3);

  // Rogue operates
  earnReputation(state, bus, ids.lira as any, ReputationTrack.SHADOW, 15);

  // Noble patronage (Agnes sponsors construction)
  payTax(state, bus, ids.agnes as any, 20); // political contribution
  earnReputation(state, bus, ids.agnes as any, ReputationTrack.CROWN, 10);

  // Everyone eats
  for (const charId of Object.values(ids)) {
    buyFood(state, bus, charId as any, 3);
  }

  // Complete some quests
  if (state.quests.length > 0) {
    doCompleteQuest(state, bus, state.quests[0].id, ids.pip as any);
  }

  console.log(`  ✓ Economic activity seeded (${state.economy.transactionLog.length} transactions)`);

  // ── Build reputation toward first title threshold ──────────────
  // Give Brennan enough Honor to reach "Trusted" (50)
  earnReputation(state, bus, ids.brennan as any, ReputationTrack.HONOR, 40);
  // Give Margaux Guild Standing toward "Recognized" (50)
  earnReputation(state, bus, ids.margaux as any, ReputationTrack.GUILD, 45);

  console.log(`  ✓ Reputation milestones seeded`);

  const snapshot = getEconomySnapshot(state);
  console.log(`  ✓ Economy: ${snapshot.moneySupply}d total supply, ${snapshot.averageWealth}d avg wealth`);
  console.log(`  ✓ Chronicle: ${state.chronicle.entries.length} entries`);
  console.log(`  ✓ Titles granted: ${state.titles.length}`);

  return { state, bus, characterIds: ids };
}
