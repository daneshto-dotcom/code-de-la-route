// ═══════════════════════════════════════════════════════════════════
// EVENT BUS — All inter-module communication flows through here.
// Modules publish events. Other modules subscribe to them.
// No module ever calls another module's functions directly.
// ═══════════════════════════════════════════════════════════════════

import {
  CharacterId, HouseholdId, GuildId, SettlementId, QuestId,
  TitleId, DayPhase, Season, ReputationTrack, TransactionType,
  SettlementTier, LifeStage, CharacterClass,
} from "../types";

// ── Event Definitions ────────────────────────────────────────────

export interface GameEvents {
  // TIME module
  "time:dayPhaseChanged": { oldPhase: DayPhase; newPhase: DayPhase; tick: number };
  "time:newDay": { day: number; year: number; season: Season; tick: number };
  "time:seasonChanged": { oldSeason: Season; newSeason: Season; year: number; tick: number };
  "time:yearChanged": { oldYear: number; newYear: number; tick: number };
  "time:characterAged": { characterId: CharacterId; newAge: number; lifeStage: LifeStage; tick: number };

  // ECONOMY module
  "economy:transactionCompleted": { type: TransactionType; fromId: string; toId: string; amount: number; tick: number };
  "economy:priceChanged": { itemName: string; oldPrice: number; newPrice: number };
  "economy:inflationAlert": { level: "GREEN" | "YELLOW" | "ORANGE" | "RED"; velocity: number; moneySupply: number };

  // CHARACTER module
  "character:created": { characterId: CharacterId; householdId: HouseholdId; class: CharacterClass; tick: number };
  "character:died": { characterId: CharacterId; householdId: HouseholdId; cause: string; age: number; tick: number };
  "character:retired": { characterId: CharacterId; householdId: HouseholdId; tick: number };
  "character:rankAdvanced": { characterId: CharacterId; class: CharacterClass; newRank: number; title: string; tick: number };

  // REPUTATION module
  "reputation:changed": { characterId: CharacterId; track: ReputationTrack; oldScore: number; newScore: number; tick: number };
  "reputation:titleGranted": { characterId: CharacterId; titleId: TitleId; titleName: string; category: string; tick: number };

  // HOUSEHOLD module
  "household:created": { householdId: HouseholdId; name: string; tick: number };
  "household:inheritanceProcessed": { householdId: HouseholdId; deceasedId: CharacterId; inherited: number; lost: number; tick: number };

  // SETTLEMENT module
  "settlement:founded": { settlementId: SettlementId; name: string; founderId: HouseholdId; zone: string; tick: number };
  "settlement:tierChanged": { settlementId: SettlementId; name: string; oldTier: SettlementTier; newTier: SettlementTier; tick: number };
  "settlement:structureBuilt": { settlementId: SettlementId; structure: string; tick: number };

  // GUILD module
  "guild:chartered": { guildId: GuildId; name: string; type: string; founderId: CharacterId; tick: number };
  "guild:dissolved": { guildId: GuildId; name: string; reason: string; tick: number };
  "guild:memberJoined": { guildId: GuildId; characterId: CharacterId; tick: number };

  // QUEST module
  "quest:completed": { questId: QuestId; characterId: CharacterId; title: string; significance: string; tick: number };

  // CHRONICLE (receives, rarely publishes)
  "chronicle:entryCreated": { entryId: string; title: string; significance: string; year: number; tick: number };
  "chronicle:yearSealed": { year: number; totalEntries: number; tick: number };
}

export type EventName = keyof GameEvents;
export type EventPayload<E extends EventName> = GameEvents[E];
type Handler<E extends EventName> = (payload: EventPayload<E>) => void;

export class EventBus {
  private handlers: Map<string, Array<(payload: any) => void>> = new Map();
  private eventLog: Array<{ event: string; payload: any; tick: number }> = [];
  private logEnabled: boolean;

  constructor(logEnabled = false) {
    this.logEnabled = logEnabled;
  }

  on<E extends EventName>(event: E, handler: Handler<E>): void {
    if (!this.handlers.has(event)) {
      this.handlers.set(event, []);
    }
    this.handlers.get(event)!.push(handler);
  }

  emit<E extends EventName>(event: E, payload: EventPayload<E>): void {
    if (this.logEnabled) {
      this.eventLog.push({ event, payload, tick: (payload as any).tick ?? 0 });
    }
    const handlers = this.handlers.get(event);
    if (handlers) {
      for (const handler of handlers) {
        handler(payload);
      }
    }
  }

  getLog(): ReadonlyArray<{ event: string; payload: any; tick: number }> {
    return this.eventLog;
  }

  getLogByEvent(event: EventName): ReadonlyArray<{ event: string; payload: any; tick: number }> {
    return this.eventLog.filter(e => e.event === event);
  }

  clearLog(): void {
    this.eventLog = [];
  }
}
