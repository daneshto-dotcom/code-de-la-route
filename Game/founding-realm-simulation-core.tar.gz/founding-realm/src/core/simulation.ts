// ═══════════════════════════════════════════════════════════════════
// SIMULATION ORCHESTRATOR
// The single object that holds all game state and drives the loop.
// This is the "SIMULATION LAYER" — no I/O, no networking, no UI.
// ═══════════════════════════════════════════════════════════════════

import {
  WorldClock, Character, Household, Guild, Settlement, Quest, Title,
  CharacterId, HouseholdId, ReputationScores, ReputationTrack,
  CharacterClass, TransactionType, Season, ZoneId,
} from "../types";
import { EventBus } from "./events";
import { createInitialClock, advanceTick, fastForwardDays } from "../modules/time";
import { EconomyState, createEconomyState, processTransaction, computeEconomySnapshot, resetDailyCounters, resetSeasonalCounters } from "../modules/economy";
import { createCharacter, advanceRank, retireCharacter, killCharacter, updateAge } from "../modules/character";
import { createHousehold, processInheritance, calculateHeritageBonus } from "../modules/household";
import { createReputationScores, modifyReputation, totalReputation } from "../modules/reputation";
import { foundSettlement, addResident, buildStructure, reviewSettlementTier, applyDecay } from "../modules/settlement";
import { charterGuild, addMember as addGuildMember, collectDues, checkDissolution } from "../modules/guild";
import { generateDailyQuests, acceptQuest, completeQuest } from "../modules/quest";
import { ChronicleState, createChronicleState, wireChronicleListeners, getEntriesByYear } from "../modules/chronicle";
import { getStartZone } from "../modules/world";

// ── The Complete Game State ──────────────────────────────────────

export interface GameState {
  clock: WorldClock;
  economy: EconomyState;
  characters: Map<CharacterId, Character>;
  households: Map<HouseholdId, Household>;
  reputations: Map<CharacterId, ReputationScores>;
  titles: Title[];
  guilds: Map<string, Guild>;
  settlements: Map<string, Settlement>;
  quests: Quest[];
  chronicle: ChronicleState;
  balances: Map<CharacterId, number>;  // denormalized for fast access
}

export function createGameState(startYear = 1601): { state: GameState; bus: EventBus } {
  const bus = new EventBus(true); // logging enabled
  const state: GameState = {
    clock: createInitialClock(startYear),
    economy: createEconomyState(),
    characters: new Map(),
    households: new Map(),
    reputations: new Map(),
    titles: [],
    guilds: new Map(),
    settlements: new Map(),
    quests: [],
    chronicle: createChronicleState(),
    balances: new Map(),
  };

  // Wire chronicle listeners
  wireChronicleListeners(
    state,
    bus,
    () => ({
      year: state.clock.currentYear,
      season: state.clock.currentSeason,
      day: state.clock.currentDay,
      tickCount: state.clock.tickCount,
    }),
  );

  // Wire time → economy resets
  bus.on("time:dayPhaseChanged", (payload) => {
    if (payload.newPhase === "DAWN") {
      resetDailyCounters(state.economy);
      // Generate daily quests
      state.quests = [
        ...state.quests.filter(q => q.status !== "AVAILABLE" && q.status !== "EXPIRED"),
        ...generateDailyQuests(payload.tick),
      ];
    }
  });

  bus.on("time:seasonChanged", () => {
    resetSeasonalCounters(state.economy);
    // Apply settlement decay each season
    for (const [id, stl] of state.settlements) {
      state.settlements.set(id, applyDecay(stl, 5));
    }
  });

  bus.on("time:yearChanged", (payload) => {
    // Review settlement tiers
    for (const [id, stl] of state.settlements) {
      state.settlements.set(id, reviewSettlementTier(stl, payload.tick, bus));
    }
    // Check guild dissolution
    for (const [id, guild] of state.guilds) {
      state.guilds.set(id, checkDissolution(guild, payload.tick, bus));
    }
  });

  // Wire aging
  bus.on("time:characterAged", (payload) => {
    const char = state.characters.get(payload.characterId);
    if (char && char.status === "ACTIVE") {
      state.characters.set(char.id, updateAge(char, payload.newAge));
      // Natural death check (randomized 70–80)
      if (payload.newAge >= 70 && Math.random() < (payload.newAge - 69) * 0.1) {
        const dead = killCharacter(char, "natural causes", bus, payload.tick);
        state.characters.set(dead.id, dead);
      }
    }
  });

  return { state, bus };
}

// ── High-Level Actions (called by networking layer or tests) ────

export function spawnCharacter(
  state: GameState, bus: EventBus,
  name: string, charClass: CharacterClass, householdName: string,
): CharacterId {
  // Create or find household
  let household: Household | undefined;
  for (const hh of state.households.values()) {
    if (hh.name === householdName) { household = hh; break; }
  }
  if (!household) {
    household = createHousehold(householdName, state.clock.tickCount, bus);
    state.households.set(household.id, household);
  }

  const heritage = calculateHeritageBonus(household);
  const zone = getStartZone(charClass);
  const char = createCharacter(
    name, charClass, household.id, zone,
    state.clock.currentYear, state.clock.tickCount, bus,
    heritage.wealthBonus,
  );

  state.characters.set(char.id, char);
  state.reputations.set(char.id, createReputationScores());
  state.balances.set(char.id, char.balance);
  state.economy.totalMoneySupply += char.balance;

  return char.id;
}

export function performLabor(
  state: GameState, bus: EventBus, charId: CharacterId, wage: number,
): boolean {
  const result = processTransaction(
    { type: TransactionType.LABOR_WAGE, fromId: "SYSTEM", toId: charId, amount: wage, description: "Labor wage" },
    state.balances, state.economy, bus,
    state.clock.tickCount, state.clock.currentYear, state.clock.currentSeason,
  );
  if (result.success) {
    const char = state.characters.get(charId);
    if (char) state.characters.set(charId, { ...char, balance: state.balances.get(charId) ?? char.balance });
  }
  return result.success;
}

export function payTax(
  state: GameState, bus: EventBus, charId: CharacterId, amount: number,
): boolean {
  const result = processTransaction(
    { type: TransactionType.TAX, fromId: charId, toId: "SYSTEM", amount, description: "Tax payment" },
    state.balances, state.economy, bus,
    state.clock.tickCount, state.clock.currentYear, state.clock.currentSeason,
  );
  if (result.success) {
    const char = state.characters.get(charId);
    if (char) state.characters.set(charId, { ...char, balance: state.balances.get(charId) ?? char.balance });
  }
  return result.success;
}

export function buyFood(
  state: GameState, bus: EventBus, charId: CharacterId, cost: number,
): boolean {
  const result = processTransaction(
    { type: TransactionType.FOOD_PURCHASE, fromId: charId, toId: "NPC", amount: cost, description: "Food purchase" },
    state.balances, state.economy, bus,
    state.clock.tickCount, state.clock.currentYear, state.clock.currentSeason,
  );
  if (result.success) {
    const char = state.characters.get(charId);
    if (char) {
      state.characters.set(charId, { ...char, hunger: 100, balance: state.balances.get(charId) ?? char.balance });
    }
  }
  return result.success;
}

export function earnReputation(
  state: GameState, bus: EventBus, charId: CharacterId,
  track: ReputationTrack, amount: number,
): void {
  const scores = state.reputations.get(charId);
  if (!scores) return;
  const { scores: newScores, newTitles } = modifyReputation(
    charId, scores, track, amount, state.titles, bus,
    state.clock.tickCount, state.clock.currentYear,
  );
  state.reputations.set(charId, newScores);
  state.titles.push(...newTitles);
}

export function doCompleteQuest(
  state: GameState, bus: EventBus, questId: string, charId: CharacterId,
): boolean {
  const qIdx = state.quests.findIndex(q => q.id === questId);
  if (qIdx === -1) return false;
  let quest = state.quests[qIdx];
  quest = acceptQuest(quest, charId);
  quest = completeQuest(quest, bus, state.clock.tickCount);
  state.quests[qIdx] = quest;
  if (quest.status === "COMPLETED") {
    // Pay reward
    processTransaction(
      { type: TransactionType.QUEST_REWARD, fromId: "SYSTEM", toId: charId, amount: quest.rewardDeniers, description: `Quest: ${quest.title}` },
      state.balances, state.economy, bus,
      state.clock.tickCount, state.clock.currentYear, state.clock.currentSeason,
    );
    const char = state.characters.get(charId);
    if (char) state.characters.set(charId, { ...char, balance: state.balances.get(charId) ?? char.balance });
    // Reputation reward
    if (quest.rewardReputation) {
      earnReputation(state, bus, charId, quest.rewardReputation.track, quest.rewardReputation.amount);
    }
    return true;
  }
  return false;
}

export function doFoundSettlement(
  state: GameState, bus: EventBus, name: string, zone: ZoneId, charId: CharacterId,
): string | null {
  const char = state.characters.get(charId);
  if (!char) return null;
  const stl = foundSettlement(name, zone, char.householdId, state.clock.currentYear, state.clock.tickCount, bus);
  const withResident = addResident(stl, charId);
  state.settlements.set(stl.id, withResident);
  return stl.id;
}

export function doCharterGuild(
  state: GameState, bus: EventBus, name: string, type: string, founderId: CharacterId,
): string | null {
  const { GuildType: GT } = require("../types");
  const guildType = GT[type as keyof typeof GT];
  if (!guildType) return null;
  const guild = charterGuild(
    name, guildType, founderId, null,
    state.clock.currentYear, 30, 5, state.clock.tickCount, bus,
  );
  state.guilds.set(guild.id, guild);
  return guild.id;
}

/** Advance the simulation by one tick */
export function tick(state: GameState, bus: EventBus, ticksPerGameMinute = 5): void {
  const ageableChars = Array.from(state.characters.values())
    .filter(c => c.status === "ACTIVE")
    .map(c => ({ id: c.id, birthYear: c.birthYear }));

  state.clock = advanceTick(state.clock, bus, ticksPerGameMinute, ageableChars);
}

/** Fast-forward by N game-days */
export function advanceDays(state: GameState, bus: EventBus, days: number): void {
  const ageableChars = Array.from(state.characters.values())
    .filter(c => c.status === "ACTIVE")
    .map(c => ({ id: c.id, birthYear: c.birthYear }));

  state.clock = fastForwardDays(state.clock, bus, days, ageableChars);
}

/** Get economy snapshot */
export function getEconomySnapshot(state: GameState) {
  const activePlayers = Array.from(state.characters.values()).filter(c => c.status === "ACTIVE").length;
  return computeEconomySnapshot(state.economy, activePlayers);
}
