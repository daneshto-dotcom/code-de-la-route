// Global declarations for Node.js runtime without @types/node
declare var console: {
  log(...args: any[]): void;
  error(...args: any[]): void;
  warn(...args: any[]): void;
};
declare var process: {
  argv: string[];
  exit(code?: number): void;
  env: Record<string, string | undefined>;
};
declare function require(id: string): any;
declare var __dirname: string;
declare var __filename: string;
declare module "fs" {
  export function existsSync(path: string): boolean;
  export function mkdirSync(path: string, options?: any): void;
  export function writeFileSync(path: string, data: string, encoding?: string): void;
  export function readFileSync(path: string, encoding?: string): string;
}
declare module "path" {
  export function dirname(p: string): string;
  export function join(...paths: string[]): string;
}
