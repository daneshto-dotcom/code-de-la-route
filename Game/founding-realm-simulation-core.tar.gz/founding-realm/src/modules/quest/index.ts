// ═══════════════════════════════════════════════════════════════════
// QUEST MODULE
// ═══════════════════════════════════════════════════════════════════

import {
  Quest, QuestId, QuestType, QuestStatus, CharacterId,
  ReputationTrack, makeId,
} from "../../types";
import { EventBus } from "../../core/events";

const QUEST_TEMPLATES: Array<{
  type: QuestType; title: string; description: string;
  rewardDeniers: [number, number]; repTrack: ReputationTrack | null; repAmount: number;
}> = [
  { type: QuestType.LABOR, title: "Haul Stone to the Market", description: "Carry 3 loads of stone from the quarry to Market Row.", rewardDeniers: [8, 15], repTrack: null, repAmount: 0 },
  { type: QuestType.LABOR, title: "Clear the North Path", description: "Remove debris blocking the north road.", rewardDeniers: [10, 18], repTrack: ReputationTrack.HONOR, repAmount: 3 },
  { type: QuestType.DELIVERY, title: "Letter to the Chancellor", description: "Deliver a sealed letter to the Scriptorium.", rewardDeniers: [5, 12], repTrack: ReputationTrack.CROWN, repAmount: 2 },
  { type: QuestType.GATHERING, title: "Herbs for the Sanctuary", description: "Gather 5 bundles of healing herbs from the Wild.", rewardDeniers: [12, 20], repTrack: ReputationTrack.GUILD, repAmount: 3 },
  { type: QuestType.COMBAT, title: "Bandit Camp on the East Ridge", description: "A bandit camp has been spotted near the Wild. Clear it.", rewardDeniers: [25, 50], repTrack: ReputationTrack.HONOR, repAmount: 10 },
  { type: QuestType.INVESTIGATION, title: "The Missing Grain Shipment", description: "A grain delivery never arrived at Ashwood. Find out why.", rewardDeniers: [20, 35], repTrack: ReputationTrack.CROWN, repAmount: 5 },
  { type: QuestType.LABOR, title: "Dig a Well for Millbrook", description: "Help the settlers of Millbrook dig a communal well.", rewardDeniers: [12, 20], repTrack: ReputationTrack.HONOR, repAmount: 5 },
  { type: QuestType.GATHERING, title: "Iron Ore for the Blacksmith", description: "Mine 3 loads of iron ore from the eastern ridge.", rewardDeniers: [15, 25], repTrack: ReputationTrack.GUILD, repAmount: 4 },
  { type: QuestType.DELIVERY, title: "Supply Run to the Garrison", description: "Deliver rations to Captain Dael at the Garrison.", rewardDeniers: [8, 15], repTrack: ReputationTrack.HONOR, repAmount: 3 },
  { type: QuestType.POLITICAL, title: "Gather Signatures for a Petition", description: "Collect 5 signatures from settlement elders supporting the new trade law.", rewardDeniers: [15, 30], repTrack: ReputationTrack.CROWN, repAmount: 8 },
];

export function generateDailyQuests(tick: number, count = 5): Quest[] {
  const quests: Quest[] = [];
  const shuffled = [...QUEST_TEMPLATES].sort(() => Math.random() - 0.5);
  for (let i = 0; i < Math.min(count, shuffled.length); i++) {
    const tmpl = shuffled[i];
    const reward = tmpl.rewardDeniers[0] + Math.floor(Math.random() * (tmpl.rewardDeniers[1] - tmpl.rewardDeniers[0] + 1));
    quests.push({
      id: makeId<QuestId>("qst"),
      type: tmpl.type,
      title: tmpl.title,
      description: tmpl.description,
      status: QuestStatus.AVAILABLE,
      assignedTo: null,
      rewardDeniers: reward,
      rewardReputation: tmpl.repTrack ? { track: tmpl.repTrack, amount: tmpl.repAmount } : null,
      significance: tmpl.type === QuestType.COMBAT || tmpl.type === QuestType.INVESTIGATION ? "MAJOR" : "MINOR",
      createdAt: tick,
      expiresAt: null,
    });
  }
  return quests;
}

export function acceptQuest(quest: Quest, characterId: CharacterId): Quest {
  if (quest.status !== QuestStatus.AVAILABLE) return quest;
  return { ...quest, status: QuestStatus.ACCEPTED, assignedTo: characterId };
}

export function completeQuest(quest: Quest, bus: EventBus, tick: number): Quest {
  if (quest.status !== QuestStatus.ACCEPTED || !quest.assignedTo) return quest;
  const completed = { ...quest, status: QuestStatus.COMPLETED };
  bus.emit("quest:completed", {
    questId: quest.id,
    characterId: quest.assignedTo,
    title: quest.title,
    significance: quest.significance,
    tick,
  });
  return completed;
}
