// ═══════════════════════════════════════════════════════════════════
// CHARACTER MODULE
// ═══════════════════════════════════════════════════════════════════

import {
  Character, CharacterId, HouseholdId, CharacterClass, CharacterStatus,
  LifeStage, ZoneId, CLASS_STARTING_CONDITIONS, makeId,
} from "../../types";
import { EventBus } from "../../core/events";
import { getLifeStage } from "../time";

export function createCharacter(
  name: string,
  charClass: CharacterClass,
  householdId: HouseholdId,
  startZone: ZoneId,
  currentYear: number,
  tick: number,
  bus: EventBus,
  heritageBonusWealth = 0,
): Character {
  const starting = CLASS_STARTING_CONDITIONS[charClass];
  const startBalance = Math.min(starting.balance + heritageBonusWealth, starting.balance * 2);
  const age = 18;
  const char: Character = {
    id: makeId<CharacterId>("chr"),
    householdId,
    name,
    class: charClass,
    rank: starting.rank,
    age,
    birthYear: currentYear - age,
    status: CharacterStatus.ACTIVE,
    lifeStage: LifeStage.YOUTH,
    zone: startZone,
    hunger: 80,
    balance: startBalance,
    createdAt: tick,
  };

  bus.emit("character:created", {
    characterId: char.id,
    householdId,
    class: charClass,
    tick,
  });

  return char;
}

export function advanceRank(
  char: Character,
  bus: EventBus,
  tick: number,
): Character {
  if (char.rank >= 5) return char;
  const updated = { ...char, rank: char.rank + 1 };
  const titles: Record<string, string[]> = require("../../types").CLASS_RANK_TITLES;
  const title = titles[char.class]?.[updated.rank - 1] ?? `Rank ${updated.rank}`;
  bus.emit("character:rankAdvanced", {
    characterId: char.id,
    class: char.class,
    newRank: updated.rank,
    title,
    tick,
  });
  return updated;
}

export function retireCharacter(char: Character, bus: EventBus, tick: number): Character {
  const updated = { ...char, status: CharacterStatus.RETIRED };
  bus.emit("character:retired", {
    characterId: char.id,
    householdId: char.householdId,
    tick,
  });
  return updated;
}

export function killCharacter(char: Character, cause: string, bus: EventBus, tick: number): Character {
  const updated = { ...char, status: CharacterStatus.DEAD };
  bus.emit("character:died", {
    characterId: char.id,
    householdId: char.householdId,
    cause,
    age: char.age,
    tick,
  });
  return updated;
}

export function updateAge(char: Character, newAge: number): Character {
  return { ...char, age: newAge, lifeStage: getLifeStage(newAge) };
}
