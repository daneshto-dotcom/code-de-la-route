// ═══════════════════════════════════════════════════════════════════
// HOUSEHOLD MODULE — Dynasty persistence container
// ═══════════════════════════════════════════════════════════════════

import { Household, HouseholdId, CharacterId, makeId } from "../../types";
import { EventBus } from "../../core/events";

export function createHousehold(name: string, tick: number, bus: EventBus): Household {
  const household: Household = {
    id: makeId<HouseholdId>("hh"),
    name,
    treasury: 0,
    generation: 1,
    reputationAggregate: 0,
    createdAt: tick,
  };
  bus.emit("household:created", { householdId: household.id, name, tick });
  return household;
}

/**
 * Process inheritance when a character dies or retires.
 * 50% of character balance → household treasury. 50% lost ("funeral costs").
 */
export function processInheritance(
  household: Household,
  deceasedId: CharacterId,
  characterBalance: number,
  peakReputation: number,
  bus: EventBus,
  tick: number,
): Household {
  const inherited = Math.floor(characterBalance * 0.5);
  const lost = characterBalance - inherited;

  const updated: Household = {
    ...household,
    treasury: household.treasury + inherited,
    generation: household.generation + 1,
    reputationAggregate: household.reputationAggregate + peakReputation,
  };

  bus.emit("household:inheritanceProcessed", {
    householdId: household.id,
    deceasedId,
    inherited,
    lost,
    tick,
  });

  return updated;
}

/**
 * Calculate Heritage Bonus for the next character in the lineage.
 */
export function calculateHeritageBonus(household: Household): {
  wealthBonus: number;
  reputationMultiplier: number;
  skillDiscount: number;
} {
  const genCap = Math.min(household.generation, 4); // cap at 3 previous generations
  return {
    wealthBonus: household.treasury,  // heir starts with household treasury
    reputationMultiplier: Math.min(1.25, 1.0 + 0.05 * genCap + (household.reputationAggregate > 500 ? 0.05 : 0)),
    skillDiscount: Math.min(0.30, 0.10 * (genCap - 1)),
  };
}
