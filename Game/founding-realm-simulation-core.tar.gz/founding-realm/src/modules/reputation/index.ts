// ═══════════════════════════════════════════════════════════════════
// REPUTATION MODULE — 4-track reputation, title thresholds
// ═══════════════════════════════════════════════════════════════════

import {
  CharacterId, ReputationTrack, ReputationScores, Title, TitleId,
  REPUTATION_THRESHOLDS, makeId,
} from "../../types";
import { EventBus } from "../../core/events";

export function createReputationScores(): ReputationScores {
  return {
    [ReputationTrack.HONOR]: 0,
    [ReputationTrack.GUILD]: 0,
    [ReputationTrack.SHADOW]: 0,
    [ReputationTrack.CROWN]: 0,
  };
}

/**
 * Modify a reputation track for a character. Clamps to 0–999.
 * Checks for threshold crossings and grants/revokes titles.
 */
export function modifyReputation(
  characterId: CharacterId,
  scores: ReputationScores,
  track: ReputationTrack,
  delta: number,
  existingTitles: Title[],
  bus: EventBus,
  tick: number,
  year: number,
): { scores: ReputationScores; newTitles: Title[] } {
  const oldScore = scores[track];
  const newScore = Math.max(0, Math.min(999, oldScore + delta));
  const updatedScores = { ...scores, [track]: newScore };

  bus.emit("reputation:changed", {
    characterId,
    track,
    oldScore,
    newScore,
    tick,
  });

  // Check threshold crossings
  const thresholds = REPUTATION_THRESHOLDS[track];
  const newTitles: Title[] = [];

  for (const { threshold, title } of thresholds) {
    const hadIt = oldScore >= threshold;
    const hasIt = newScore >= threshold;

    if (!hadIt && hasIt) {
      // Crossed upward — grant title
      const titleRecord: Title = {
        id: makeId<TitleId>("ttl"),
        characterId,
        name: title,
        category: "REPUTATION",
        grantedAt: tick,
        grantedYear: year,
        active: true,
      };
      newTitles.push(titleRecord);

      bus.emit("reputation:titleGranted", {
        characterId,
        titleId: titleRecord.id,
        titleName: title,
        category: "REPUTATION",
        tick,
      });
    }
    // Note: title revocation on downward crossing can be added later
  }

  return { scores: updatedScores, newTitles };
}

/** Get the highest active title for a given track */
export function getHighestTitle(
  scores: ReputationScores,
  track: ReputationTrack,
): string | null {
  const thresholds = REPUTATION_THRESHOLDS[track];
  let highest: string | null = null;
  for (const { threshold, title } of thresholds) {
    if (scores[track] >= threshold) highest = title;
  }
  return highest;
}

/** Sum all reputation scores (for household aggregate) */
export function totalReputation(scores: ReputationScores): number {
  return scores[ReputationTrack.HONOR]
    + scores[ReputationTrack.GUILD]
    + scores[ReputationTrack.CROWN];
  // Shadow intentionally excluded from aggregate
}
