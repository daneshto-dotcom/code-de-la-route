// ═══════════════════════════════════════════════════════════════════
// GUILD MODULE
// ═══════════════════════════════════════════════════════════════════

import {
  Guild, GuildId, GuildType, GuildStatus, CharacterId,
  SettlementId, makeId,
} from "../../types";
import { EventBus } from "../../core/events";

export function charterGuild(
  name: string, type: GuildType, founderId: CharacterId,
  homeSettlement: SettlementId | null, year: number,
  charterFee: number, monthlyDues: number,
  tick: number, bus: EventBus,
): Guild {
  const guild: Guild = {
    id: makeId<GuildId>("gld"),
    name, type, status: GuildStatus.ACTIVE,
    treasury: 0, memberIds: [founderId], leaderId: founderId,
    homeSettlement, foundedYear: year, charterFee, monthlyDues,
    dissolvedAt: null,
  };
  bus.emit("guild:chartered", {
    guildId: guild.id, name, type, founderId, tick,
  });
  return guild;
}

export function addMember(guild: Guild, charId: CharacterId, tick: number, bus: EventBus): Guild {
  if (guild.memberIds.includes(charId)) return guild;
  bus.emit("guild:memberJoined", { guildId: guild.id, characterId: charId, tick });
  return { ...guild, memberIds: [...guild.memberIds, charId] };
}

export function removeMember(guild: Guild, charId: CharacterId): Guild {
  return {
    ...guild,
    memberIds: guild.memberIds.filter(m => m !== charId),
    leaderId: guild.leaderId === charId ? (guild.memberIds[0] ?? null) : guild.leaderId,
  };
}

export function collectDues(guild: Guild, amount: number): Guild {
  return { ...guild, treasury: guild.treasury + amount };
}

export function checkDissolution(guild: Guild, tick: number, bus: EventBus): Guild {
  if (guild.status === GuildStatus.DISSOLVED) return guild;
  if (guild.memberIds.length === 0) {
    bus.emit("guild:dissolved", {
      guildId: guild.id, name: guild.name, reason: "No remaining members", tick,
    });
    return { ...guild, status: GuildStatus.DISSOLVED, dissolvedAt: tick };
  }
  if (guild.memberIds.length < 3 && guild.status === GuildStatus.ACTIVE) {
    return { ...guild, status: GuildStatus.PROBATION };
  }
  if (guild.memberIds.length >= 3 && guild.status === GuildStatus.PROBATION) {
    return { ...guild, status: GuildStatus.ACTIVE };
  }
  return guild;
}
