// ═══════════════════════════════════════════════════════════════════
// CHRONICLE MODULE — The world's permanent memory.
// ═══════════════════════════════════════════════════════════════════

import {
  ChronicleEntry, ChronicleEntryId, ChronicleSignificance,
  CharacterId, GuildId, SettlementId, Season, makeId,
} from "../../types";
import { EventBus } from "../../core/events";

export interface ChronicleState {
  entries: ChronicleEntry[];
  buffer: ChronicleEntry[];   // unflushed entries
}

export function createChronicleState(): ChronicleState {
  return { entries: [], buffer: [] };
}

export function addEntry(
  state: ChronicleState,
  title: string,
  description: string,
  significance: ChronicleSignificance,
  year: number,
  season: Season,
  day: number,
  characterIds: CharacterId[] = [],
  guildId: GuildId | null = null,
  settlementId: SettlementId | null = null,
  tags: string[] = [],
  bus?: EventBus,
  tick = 0,
): ChronicleState {
  const entry: ChronicleEntry = {
    id: makeId<ChronicleEntryId>("chr"),
    year, season, day, title, description, significance,
    characterIds, guildId, settlementId, tags, sealed: false,
  };
  const updated = {
    entries: [...state.entries, entry],
    buffer: [...state.buffer, entry],
  };
  if (bus) {
    bus.emit("chronicle:entryCreated", {
      entryId: entry.id, title, significance, year, tick,
    });
  }
  return updated;
}

export function flushBuffer(state: ChronicleState): ChronicleState {
  return { ...state, buffer: [] };
}

export function sealYear(state: ChronicleState, year: number, bus: EventBus, tick: number): ChronicleState {
  const entries = state.entries.map(e =>
    e.year === year ? { ...e, sealed: true } : e
  );
  const count = entries.filter(e => e.year === year).length;
  bus.emit("chronicle:yearSealed", { year, totalEntries: count, tick });
  return { ...state, entries };
}

export function getEntriesByYear(state: ChronicleState, year: number): ChronicleEntry[] {
  return state.entries.filter(e => e.year === year);
}

export function getEntriesByCharacter(state: ChronicleState, charId: CharacterId): ChronicleEntry[] {
  return state.entries.filter(e => e.characterIds.includes(charId));
}

export function getEntriesBySettlement(state: ChronicleState, stlId: SettlementId): ChronicleEntry[] {
  return state.entries.filter(e => e.settlementId === stlId);
}

/** Wire up the Chronicle to listen for notable events from other modules */
export function wireChronicleListeners(
  state: { chronicle: ChronicleState },
  bus: EventBus,
  getClock: () => { year: number; season: Season; day: number; tickCount: number },
): void {
  bus.on("settlement:founded", (payload) => {
    const clock = getClock();
    state.chronicle = addEntry(
      state.chronicle,
      `${payload.name} Founded`,
      `A new settlement called ${payload.name} was founded in the ${payload.zone}.`,
      ChronicleSignificance.MAJOR,
      clock.year, clock.season, clock.day,
      [], null, payload.settlementId, ["settlement", "founding"],
      bus, clock.tickCount,
    );
  });

  bus.on("settlement:tierChanged", (payload) => {
    const clock = getClock();
    state.chronicle = addEntry(
      state.chronicle,
      `${payload.name} Grows`,
      `The settlement of ${payload.name} advanced from tier ${payload.oldTier} to tier ${payload.newTier}.`,
      ChronicleSignificance.MAJOR,
      clock.year, clock.season, clock.day,
      [], null, payload.settlementId, ["settlement", "growth"],
      bus, clock.tickCount,
    );
  });

  bus.on("guild:chartered", (payload) => {
    const clock = getClock();
    state.chronicle = addEntry(
      state.chronicle,
      `${payload.name} Chartered`,
      `The ${payload.name} (${payload.type}) was formally chartered.`,
      ChronicleSignificance.MAJOR,
      clock.year, clock.season, clock.day,
      [payload.founderId], payload.guildId, null, ["guild", "charter"],
      bus, clock.tickCount,
    );
  });

  bus.on("character:died", (payload) => {
    const clock = getClock();
    state.chronicle = addEntry(
      state.chronicle,
      `Death of a Realm Citizen`,
      `A citizen of the Realm has passed at age ${payload.age}. Cause: ${payload.cause}.`,
      ChronicleSignificance.MAJOR,
      clock.year, clock.season, clock.day,
      [payload.characterId], null, null, ["death", "obituary"],
      bus, clock.tickCount,
    );
  });

  bus.on("reputation:titleGranted", (payload) => {
    const clock = getClock();
    state.chronicle = addEntry(
      state.chronicle,
      `Title Granted: ${payload.titleName}`,
      `A citizen earned the title "${payload.titleName}".`,
      ChronicleSignificance.MINOR,
      clock.year, clock.season, clock.day,
      [payload.characterId], null, null, ["title", payload.category.toLowerCase()],
      bus, clock.tickCount,
    );
  });

  bus.on("quest:completed", (payload) => {
    if (payload.significance === "MAJOR") {
      const clock = getClock();
      state.chronicle = addEntry(
        state.chronicle,
        `Quest Completed: ${payload.title}`,
        `The quest "${payload.title}" has been completed.`,
        ChronicleSignificance.MINOR,
        clock.year, clock.season, clock.day,
        [payload.characterId], null, null, ["quest"],
        bus, clock.tickCount,
      );
    }
  });

  bus.on("time:yearChanged", (payload) => {
    state.chronicle = sealYear(state.chronicle, payload.oldYear, bus, payload.tick);
  });
}
