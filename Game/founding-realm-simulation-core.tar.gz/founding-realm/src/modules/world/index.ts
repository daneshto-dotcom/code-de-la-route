// ═══════════════════════════════════════════════════════════════════
// WORLD MODULE — Zone definitions and static geography
// ═══════════════════════════════════════════════════════════════════

import { Zone, ZoneId, ZoneSafety } from "../../types";

export const ZONES: Zone[] = [
  { id: "zone_court" as ZoneId, name: "court", inWorldName: "The Sovereign's Court", ring: 0, safety: ZoneSafety.SAFE, buildable: false },
  { id: "zone_scriptorium" as ZoneId, name: "scriptorium", inWorldName: "The Scriptorium", ring: 0, safety: ZoneSafety.SAFE, buildable: false },
  { id: "zone_gate" as ZoneId, name: "gate", inWorldName: "The Crown Gate", ring: 1, safety: ZoneSafety.SAFE, buildable: false },
  { id: "zone_market" as ZoneId, name: "market", inWorldName: "Market Row", ring: 1, safety: ZoneSafety.MODERATE, buildable: false },
  { id: "zone_commons" as ZoneId, name: "commons", inWorldName: "The Commons", ring: 1, safety: ZoneSafety.SAFE, buildable: false },
  { id: "zone_anvil" as ZoneId, name: "anvil", inWorldName: "The Anvil Quarter", ring: 1, safety: ZoneSafety.SAFE, buildable: false },
  { id: "zone_hearth" as ZoneId, name: "hearth", inWorldName: "The Hearth", ring: 1, safety: ZoneSafety.SAFE, buildable: false },
  { id: "zone_sanctuary" as ZoneId, name: "sanctuary", inWorldName: "The Sanctuary", ring: 1, safety: ZoneSafety.SAFE, buildable: false },
  { id: "zone_ashwood" as ZoneId, name: "ashwood", inWorldName: "Ashwood", ring: 2, safety: ZoneSafety.MODERATE, buildable: true },
  { id: "zone_millbrook" as ZoneId, name: "millbrook", inWorldName: "Millbrook", ring: 2, safety: ZoneSafety.MODERATE, buildable: true },
  { id: "zone_ferriers" as ZoneId, name: "ferriers", inWorldName: "Ferrier's Rest", ring: 2, safety: ZoneSafety.MODERATE, buildable: true },
  { id: "zone_garrison" as ZoneId, name: "garrison", inWorldName: "The Garrison", ring: 2, safety: ZoneSafety.MODERATE, buildable: false },
  { id: "zone_lists" as ZoneId, name: "lists", inWorldName: "The Lists", ring: 2, safety: ZoneSafety.MODERATE, buildable: false },
  { id: "zone_tankard" as ZoneId, name: "tankard", inWorldName: "The Silver Tankard", ring: 2, safety: ZoneSafety.MODERATE, buildable: false },
  { id: "zone_stable" as ZoneId, name: "stable", inWorldName: "The Stable Yard", ring: 2, safety: ZoneSafety.MODERATE, buildable: false },
  { id: "zone_fringe" as ZoneId, name: "fringe", inWorldName: "The Fringe", ring: 3, safety: ZoneSafety.LOW, buildable: false },
  { id: "zone_wild" as ZoneId, name: "wild", inWorldName: "The Wild", ring: 3, safety: ZoneSafety.LOW, buildable: false },
];

export function getZone(id: ZoneId): Zone | undefined {
  return ZONES.find(z => z.id === id);
}

export function getBuildableZones(): Zone[] {
  return ZONES.filter(z => z.buildable);
}

export function getZonesByRing(ring: 0 | 1 | 2 | 3): Zone[] {
  return ZONES.filter(z => z.ring === ring);
}

/** Default starting zone per class */
export function getStartZone(charClass: string): ZoneId {
  const map: Record<string, ZoneId> = {
    PEASANT: "zone_ashwood" as ZoneId,
    MERCHANT: "zone_market" as ZoneId,
    ARTISAN: "zone_anvil" as ZoneId,
    KNIGHT: "zone_garrison" as ZoneId,
    NOBLE: "zone_court" as ZoneId,
    ROGUE: "zone_fringe" as ZoneId,
    MONK: "zone_scriptorium" as ZoneId,
    RANGER: "zone_wild" as ZoneId,
    ADVENTURER: "zone_hearth" as ZoneId,
  };
  return map[charClass] ?? ("zone_gate" as ZoneId);
}
