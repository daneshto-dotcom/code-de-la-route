// ═══════════════════════════════════════════════════════════════════
// SETTLEMENT MODULE
// ═══════════════════════════════════════════════════════════════════

import {
  Settlement, SettlementId, SettlementTier, HouseholdId, CharacterId,
  ZoneId, SETTLEMENT_TIER_REQUIREMENTS, makeId,
} from "../../types";
import { EventBus } from "../../core/events";

export function foundSettlement(
  name: string, zone: ZoneId, founderId: HouseholdId,
  year: number, tick: number, bus: EventBus,
): Settlement {
  const settlement: Settlement = {
    id: makeId<SettlementId>("stl"),
    name, zone, tier: SettlementTier.CAMPSITE,
    population: 1, residentIds: [], founderId,
    foundedYear: year, structures: [], condition: 100, elderId: null,
  };
  bus.emit("settlement:founded", {
    settlementId: settlement.id, name, founderId, zone, tick,
  });
  return settlement;
}

export function addResident(settlement: Settlement, charId: CharacterId): Settlement {
  if (settlement.residentIds.includes(charId)) return settlement;
  return {
    ...settlement,
    residentIds: [...settlement.residentIds, charId],
    population: settlement.population + 1,
  };
}

export function buildStructure(
  settlement: Settlement, structure: string, tick: number, bus: EventBus,
): Settlement {
  const updated = {
    ...settlement,
    structures: [...settlement.structures, structure],
  };
  bus.emit("settlement:structureBuilt", {
    settlementId: settlement.id, structure, tick,
  });
  return updated;
}

export function reviewSettlementTier(
  settlement: Settlement, tick: number, bus: EventBus,
): Settlement {
  let targetTier = SettlementTier.UNCLAIMED;
  for (const [tier, req] of Object.entries(SETTLEMENT_TIER_REQUIREMENTS)) {
    const t = Number(tier) as SettlementTier;
    if (settlement.population >= req.minPopulation && settlement.structures.length >= req.minStructures) {
      targetTier = t;
    }
  }
  if (targetTier !== settlement.tier) {
    bus.emit("settlement:tierChanged", {
      settlementId: settlement.id,
      name: settlement.name,
      oldTier: settlement.tier,
      newTier: targetTier,
      tick,
    });
    return { ...settlement, tier: targetTier };
  }
  return settlement;
}

export function applyDecay(settlement: Settlement, amount: number): Settlement {
  return { ...settlement, condition: Math.max(0, settlement.condition - amount) };
}

export function applyMaintenance(settlement: Settlement, amount: number): Settlement {
  return { ...settlement, condition: Math.min(100, settlement.condition + amount) };
}
