// ═══════════════════════════════════════════════════════════════════
// ECONOMY MODULE — Currency, transactions, money supply monitoring.
// ═══════════════════════════════════════════════════════════════════

import {
  CharacterId, Transaction, TransactionType, Season,
} from "../../types";
import { EventBus } from "../../core/events";

export interface EconomyState {
  totalMoneySupply: number;
  transactionLog: Transaction[];
  dailyVolume: number;          // deniers transacted since last dawn
  seasonalVolume: number;
  taxRate: number;              // market stall tax per day (0–10d, Council-set)
  propertyTaxRate: number;      // annual % of property value (0–5%)
  npcBuyMultiplier: number;     // 0.5–1.5, admin lever for inflation control
}

export function createEconomyState(): EconomyState {
  return {
    totalMoneySupply: 0,
    transactionLog: [],
    dailyVolume: 0,
    seasonalVolume: 0,
    taxRate: 3,                 // default 3d/day stall tax
    propertyTaxRate: 2,         // default 2% annual property tax
    npcBuyMultiplier: 1.0,
  };
}

export interface TransactionRequest {
  type: TransactionType;
  fromId: CharacterId | "SYSTEM" | "NPC";
  toId: CharacterId | "SYSTEM" | "NPC";
  amount: number;
  description: string;
}

export interface CharacterBalance {
  id: CharacterId;
  balance: number;
}

/**
 * Process a transaction through the pipeline.
 * Returns { success, newBalances, transaction } or { success: false, reason }.
 * This is the ONLY way money moves in the game.
 */
export function processTransaction(
  request: TransactionRequest,
  balances: Map<CharacterId, number>,
  economyState: EconomyState,
  bus: EventBus,
  tick: number,
  year: number,
  season: Season,
): { success: true; transaction: Transaction } | { success: false; reason: string } {
  // ── VALIDATE
  if (request.amount <= 0) {
    return { success: false, reason: "Amount must be positive" };
  }

  // Check sender balance (SYSTEM and NPC have infinite funds)
  if (request.fromId !== "SYSTEM" && request.fromId !== "NPC") {
    const senderBalance = balances.get(request.fromId as CharacterId) ?? 0;
    if (senderBalance < request.amount) {
      return { success: false, reason: `Insufficient funds: has ${senderBalance}d, needs ${request.amount}d` };
    }
  }

  // ── EXECUTE (atomic)
  if (request.fromId !== "SYSTEM" && request.fromId !== "NPC") {
    const current = balances.get(request.fromId as CharacterId) ?? 0;
    balances.set(request.fromId as CharacterId, current - request.amount);
  }

  if (request.toId !== "SYSTEM" && request.toId !== "NPC") {
    const current = balances.get(request.toId as CharacterId) ?? 0;
    balances.set(request.toId as CharacterId, current + request.amount);
  }

  const transaction: Transaction = {
    type: request.type,
    fromId: request.fromId,
    toId: request.toId,
    amount: request.amount,
    description: request.description,
    tick,
    year,
    season,
  };

  economyState.transactionLog.push(transaction);
  economyState.dailyVolume += request.amount;
  economyState.seasonalVolume += request.amount;

  // Recalculate money supply (sum of all character balances)
  let total = 0;
  for (const bal of balances.values()) {
    total += bal;
  }
  economyState.totalMoneySupply = total;

  // ── PUBLISH
  bus.emit("economy:transactionCompleted", {
    type: request.type,
    fromId: request.fromId,
    toId: request.toId,
    amount: request.amount,
    tick,
  });

  return { success: true, transaction };
}

/**
 * Economy health snapshot — called every in-game dawn.
 */
export function computeEconomySnapshot(state: EconomyState, playerCount: number): {
  moneySupply: number;
  velocity: number;
  averageWealth: number;
  dailyVolume: number;
  inflationLevel: "GREEN" | "YELLOW" | "ORANGE" | "RED";
} {
  const velocity = state.totalMoneySupply > 0
    ? state.dailyVolume / state.totalMoneySupply
    : 0;

  let inflationLevel: "GREEN" | "YELLOW" | "ORANGE" | "RED" = "GREEN";
  if (velocity > 0.7) inflationLevel = "RED";
  else if (velocity > 0.5) inflationLevel = "ORANGE";
  else if (velocity > 0.4) inflationLevel = "YELLOW";

  return {
    moneySupply: state.totalMoneySupply,
    velocity: Math.round(velocity * 1000) / 1000,
    averageWealth: playerCount > 0 ? Math.round(state.totalMoneySupply / playerCount) : 0,
    dailyVolume: state.dailyVolume,
    inflationLevel,
  };
}

/** Reset daily counters (called at each in-game dawn) */
export function resetDailyCounters(state: EconomyState): void {
  state.dailyVolume = 0;
}

/** Reset seasonal counters (called at each season change) */
export function resetSeasonalCounters(state: EconomyState): void {
  state.seasonalVolume = 0;
}
