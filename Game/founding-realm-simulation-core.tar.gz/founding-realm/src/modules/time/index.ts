// ═══════════════════════════════════════════════════════════════════
// TIME MODULE — Root of the simulation. No dependencies.
// Drives the day/night cycle, seasons, years, and aging.
// ═══════════════════════════════════════════════════════════════════

import { WorldClock, DayPhase, Season, LifeStage, CharacterId } from "../../types";
import { EventBus } from "../../core/events";

const PHASE_BOUNDARIES: [number, DayPhase][] = [
  [300, DayPhase.DAWN],      // 5:00
  [420, DayPhase.MORNING],   // 7:00
  [720, DayPhase.MIDDAY],    // 12:00
  [840, DayPhase.AFTERNOON], // 14:00
  [1080, DayPhase.EVENING],  // 18:00
  [1320, DayPhase.NIGHT],    // 22:00
];

const SEASON_ORDER: Season[] = [Season.SPRING, Season.SUMMER, Season.AUTUMN, Season.WINTER];
const DAYS_PER_SEASON = 15;
const SEASON_BOUNDARIES = [1, 16, 31, 46]; // day numbers where each season starts

export function getPhaseForMinute(minute: number): DayPhase {
  let phase = DayPhase.NIGHT; // default (00:00–05:00)
  for (const [boundary, p] of PHASE_BOUNDARIES) {
    if (minute >= boundary) phase = p;
  }
  return phase;
}

export function getSeasonForDay(day: number): Season {
  if (day >= 46) return Season.WINTER;
  if (day >= 31) return Season.AUTUMN;
  if (day >= 16) return Season.SUMMER;
  return Season.SPRING;
}

export function getLifeStage(age: number): LifeStage {
  if (age <= 25) return LifeStage.YOUTH;
  if (age <= 45) return LifeStage.PRIME;
  if (age <= 60) return LifeStage.MATURITY;
  return LifeStage.ELDER;
}

export function createInitialClock(startYear = 1601): WorldClock {
  return {
    tickCount: 0,
    gameMinute: 300,        // start at dawn (5:00 AM)
    dayPhase: DayPhase.DAWN,
    currentDay: 1,
    currentSeason: Season.SPRING,
    currentYear: startYear,
  };
}

/**
 * Advance the clock by one simulation tick.
 * In real deployment: 1 tick = 1 real second, 1 game-minute = 5 real-seconds (12:1 ratio).
 * For testing: ticksPerGameMinute can be set to 1 for instant simulation.
 */
export function advanceTick(
  clock: WorldClock,
  bus: EventBus,
  ticksPerGameMinute = 5,
  ageableCharacters?: Array<{ id: CharacterId; birthYear: number }>
): WorldClock {
  const next = { ...clock, tickCount: clock.tickCount + 1 };

  // Advance game-minute every N ticks
  if (next.tickCount % ticksPerGameMinute === 0) {
    next.gameMinute = (next.gameMinute + 1) % 1440;

    // ── Day phase check
    const newPhase = getPhaseForMinute(next.gameMinute);
    if (newPhase !== clock.dayPhase) {
      bus.emit("time:dayPhaseChanged", {
        oldPhase: clock.dayPhase,
        newPhase,
        tick: next.tickCount,
      });
      next.dayPhase = newPhase;
    }

    // ── New day (midnight rollover: minute 0)
    if (next.gameMinute === 0) {
      next.currentDay += 1;

      // ── Season check
      const newSeason = getSeasonForDay(next.currentDay);
      if (newSeason !== clock.currentSeason) {
        bus.emit("time:seasonChanged", {
          oldSeason: clock.currentSeason,
          newSeason,
          year: next.currentYear,
          tick: next.tickCount,
        });
        next.currentSeason = newSeason;
      }

      // ── Year rollover (day 61 → day 1 of next year)
      if (next.currentDay > 60) {
        const oldYear = next.currentYear;
        next.currentYear += 1;
        next.currentDay = 1;
        next.currentSeason = Season.SPRING;

        bus.emit("time:yearChanged", {
          oldYear,
          newYear: next.currentYear,
          tick: next.tickCount,
        });

        // ── Age all characters
        if (ageableCharacters) {
          for (const char of ageableCharacters) {
            const newAge = next.currentYear - char.birthYear;
            bus.emit("time:characterAged", {
              characterId: char.id,
              newAge,
              lifeStage: getLifeStage(newAge),
              tick: next.tickCount,
            });
          }
        }
      }

      bus.emit("time:newDay", {
        day: next.currentDay,
        year: next.currentYear,
        season: next.currentSeason,
        tick: next.tickCount,
      });
    }
  }

  return next;
}

/**
 * Fast-forward the clock by N game-days (for testing / seed scenarios).
 * Returns the final clock state after all events have fired.
 */
export function fastForwardDays(
  clock: WorldClock,
  bus: EventBus,
  days: number,
  ageableCharacters?: Array<{ id: CharacterId; birthYear: number }>
): WorldClock {
  let c = clock;
  const ticksPerDay = 1440; // 1 tick per game-minute for fast-forward
  for (let d = 0; d < days; d++) {
    for (let t = 0; t < ticksPerDay; t++) {
      c = advanceTick(c, bus, 1, ageableCharacters);
    }
  }
  return c;
}
