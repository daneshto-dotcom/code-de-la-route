// ═══════════════════════════════════════════════════════════════════
// PERSISTENCE LAYER — Abstract interface + JSON file implementation.
// The simulation layer depends on this INTERFACE, not the implementation.
// Swap JSONPersistence for PostgresPersistence without touching simulation.
// ═══════════════════════════════════════════════════════════════════

import * as fs from "fs";
import * as path from "path";
import { GameState } from "../core/simulation";

export interface PersistenceAdapter {
  save(state: GameState): Promise<void>;
  load(): Promise<GameState | null>;
}

/** Serialization helpers — Maps don't JSON.stringify natively */
function serializeState(state: GameState): any {
  return {
    clock: state.clock,
    economy: {
      ...state.economy,
      transactionLog: state.economy.transactionLog.slice(-1000), // keep last 1000
    },
    characters: Object.fromEntries(state.characters),
    households: Object.fromEntries(state.households),
    reputations: Object.fromEntries(state.reputations),
    titles: state.titles,
    guilds: Object.fromEntries(state.guilds),
    settlements: Object.fromEntries(state.settlements),
    quests: state.quests.filter(q => q.status !== "EXPIRED"),
    chronicle: state.chronicle,
    balances: Object.fromEntries(state.balances),
  };
}

function deserializeState(data: any): Partial<GameState> {
  return {
    clock: data.clock,
    economy: data.economy,
    characters: new Map(Object.entries(data.characters ?? {})),
    households: new Map(Object.entries(data.households ?? {})),
    reputations: new Map(Object.entries(data.reputations ?? {})),
    titles: data.titles ?? [],
    guilds: new Map(Object.entries(data.guilds ?? {})),
    settlements: new Map(Object.entries(data.settlements ?? {})),
    quests: data.quests ?? [],
    chronicle: data.chronicle ?? { entries: [], buffer: [] },
    balances: new Map(Object.entries(data.balances ?? {})),
  };
}

/**
 * JSON file persistence — suitable for dev/test/single-server v1.
 * Replace with PostgresPersistence for production.
 */
export class JSONPersistence implements PersistenceAdapter {
  private filePath: string;

  constructor(filePath = "./save/realm.json") {
    this.filePath = filePath;
  }

  async save(state: GameState): Promise<void> {
    const dir = path.dirname(this.filePath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    const data = JSON.stringify(serializeState(state), null, 2);
    fs.writeFileSync(this.filePath, data, "utf-8");
  }

  async load(): Promise<GameState | null> {
    if (!fs.existsSync(this.filePath)) return null;
    const raw = fs.readFileSync(this.filePath, "utf-8");
    const data = JSON.parse(raw);
    return deserializeState(data) as GameState;
  }
}
