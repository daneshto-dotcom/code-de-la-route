// ═══════════════════════════════════════════════════════════════════
// FOUNDING REALM — Main Entry Point
// Usage:
//   npx ts-node src/main.ts seed     → Seed a new realm + print summary
//   npx ts-node src/main.ts status   → Load saved realm + print status
// ═══════════════════════════════════════════════════════════════════

import { seedRealm } from "./seed";
import { getEconomySnapshot, advanceDays, getEntriesByYear } from "./core/simulation";
import { getEntriesByYear as getChronicleEntries } from "./modules/chronicle";
import { JSONPersistence } from "./persistence";

const command = process.argv[2] ?? "seed";

async function main() {
  if (command === "seed") {
    console.log("\n╔═══════════════════════════════════════════════════╗");
    console.log("║  LEGACY OF THE REALM — FOUNDING REALM v1          ║");
    console.log("║  Simulation Core Seed                              ║");
    console.log("╚═══════════════════════════════════════════════════╝\n");

    const { state, bus, characterIds } = seedRealm();

    console.log("\n── Realm Status ──────────────────────────────────");
    console.log(`  Year: ${state.clock.currentYear} | Season: ${state.clock.currentSeason} | Day: ${state.clock.currentDay}`);
    console.log(`  Characters: ${state.characters.size}`);
    console.log(`  Households: ${state.households.size}`);
    console.log(`  Settlements: ${state.settlements.size}`);
    console.log(`  Guilds: ${state.guilds.size}`);
    console.log(`  Titles granted: ${state.titles.length}`);
    console.log(`  Chronicle entries: ${state.chronicle.entries.length}`);
    console.log(`  Quests available: ${state.quests.filter(q => q.status === "AVAILABLE").length}`);

    const snapshot = getEconomySnapshot(state);
    console.log(`\n── Economy ───────────────────────────────────────`);
    console.log(`  Money supply: ${snapshot.moneySupply}d`);
    console.log(`  Average wealth: ${snapshot.averageWealth}d`);
    console.log(`  Daily volume: ${snapshot.dailyVolume}d`);
    console.log(`  Velocity: ${snapshot.velocity}`);
    console.log(`  Inflation level: ${snapshot.inflationLevel}`);

    console.log(`\n── Characters ────────────────────────────────────`);
    for (const char of state.characters.values()) {
      const rep = state.reputations.get(char.id);
      const titles = state.titles.filter(t => t.characterId === char.id).map(t => t.name);
      const balance = state.balances.get(char.id) ?? 0;
      const titleStr = titles.length > 0 ? ` [${titles.join(", ")}]` : "";
      console.log(`  ${char.name} | ${char.class} Rank ${char.rank} | ${balance}d | Honor:${rep?.HONOR ?? 0} Guild:${rep?.GUILD ?? 0} Crown:${rep?.CROWN ?? 0} Shadow:${rep?.SHADOW ?? 0}${titleStr}`);
    }

    console.log(`\n── Settlements ───────────────────────────────────`);
    for (const stl of state.settlements.values()) {
      console.log(`  ${stl.name} | Tier ${stl.tier} | Pop: ${stl.population} | Structures: ${stl.structures.length} (${stl.structures.join(", ")})`);
    }

    console.log(`\n── Guilds ────────────────────────────────────────`);
    for (const guild of state.guilds.values()) {
      console.log(`  ${guild.name} | ${guild.type} | ${guild.status} | Members: ${guild.memberIds.length}`);
    }

    console.log(`\n── Chronicle (Year ${state.clock.currentYear}) ──`);
    for (const entry of state.chronicle.entries.slice(0, 10)) {
      console.log(`  [${entry.significance}] ${entry.title}`);
    }
    if (state.chronicle.entries.length > 10) {
      console.log(`  ... and ${state.chronicle.entries.length - 10} more entries`);
    }

    // Save
    const persistence = new JSONPersistence("./save/realm.json");
    await persistence.save(state);
    console.log(`\n  ✓ Realm saved to ./save/realm.json`);

    console.log("\n  The Realm is alive.\n");
  }
}

main().catch(console.error);
