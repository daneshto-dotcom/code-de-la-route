// ═══════════════════════════════════════════════════════════════════
// FOUNDING REALM — CORE TYPE DEFINITIONS
// All shared enums, interfaces, and types used across modules.
// No module logic lives here — only data shapes.
// ═══════════════════════════════════════════════════════════════════

// ── Identifiers ──────────────────────────────────────────────────
export type CharacterId = string & { __brand: "CharacterId" };
export type HouseholdId = string & { __brand: "HouseholdId" };
export type GuildId = string & { __brand: "GuildId" };
export type SettlementId = string & { __brand: "SettlementId" };
export type QuestId = string & { __brand: "QuestId" };
export type ChronicleEntryId = string & { __brand: "ChronicleEntryId" };
export type TitleId = string & { __brand: "TitleId" };
export type ItemTypeId = string & { __brand: "ItemTypeId" };
export type ZoneId = string & { __brand: "ZoneId" };

export function makeId<T extends string>(prefix: string): T {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}` as T;
}

// ── Time ─────────────────────────────────────────────────────────
export enum DayPhase {
  DAWN = "DAWN",
  MORNING = "MORNING",
  MIDDAY = "MIDDAY",
  AFTERNOON = "AFTERNOON",
  EVENING = "EVENING",
  NIGHT = "NIGHT",
}

export enum Season {
  SPRING = "SPRING",
  SUMMER = "SUMMER",
  AUTUMN = "AUTUMN",
  WINTER = "WINTER",
}

export interface WorldClock {
  tickCount: number;        // absolute tick counter (1 tick = 1 real second)
  gameMinute: number;       // 0–1439 (minutes in current game-day)
  dayPhase: DayPhase;
  currentDay: number;       // 1–60 within current year
  currentSeason: Season;
  currentYear: number;      // starts at 1601
}

// ── Character ────────────────────────────────────────────────────
export enum CharacterClass {
  PEASANT = "PEASANT",
  MERCHANT = "MERCHANT",
  ARTISAN = "ARTISAN",
  KNIGHT = "KNIGHT",
  NOBLE = "NOBLE",
  ROGUE = "ROGUE",
  MONK = "MONK",
  RANGER = "RANGER",
  ADVENTURER = "ADVENTURER",
}

export enum CharacterStatus {
  ACTIVE = "ACTIVE",
  WOUNDED = "WOUNDED",
  RETIRED = "RETIRED",
  DEAD = "DEAD",
}

export enum LifeStage {
  YOUTH = "YOUTH",       // 18–25
  PRIME = "PRIME",       // 26–45
  MATURITY = "MATURITY", // 46–60
  ELDER = "ELDER",       // 61+
}

export interface Character {
  id: CharacterId;
  householdId: HouseholdId;
  name: string;
  class: CharacterClass;
  rank: number;           // 1–5
  age: number;
  birthYear: number;
  status: CharacterStatus;
  lifeStage: LifeStage;
  zone: ZoneId;
  hunger: number;         // 0–100 (100 = full)
  balance: number;        // deniers held
  createdAt: number;      // tick when created
}

// ── Household ────────────────────────────────────────────────────
export interface Household {
  id: HouseholdId;
  name: string;
  treasury: number;         // deniers in family treasury
  generation: number;       // how many characters have lived
  reputationAggregate: number;
  createdAt: number;
}

// ── Reputation ───────────────────────────────────────────────────
export enum ReputationTrack {
  HONOR = "HONOR",
  GUILD = "GUILD",
  SHADOW = "SHADOW",
  CROWN = "CROWN",
}

export interface ReputationScores {
  [ReputationTrack.HONOR]: number;
  [ReputationTrack.GUILD]: number;
  [ReputationTrack.SHADOW]: number;
  [ReputationTrack.CROWN]: number;
}

export interface Title {
  id: TitleId;
  characterId: CharacterId;
  name: string;
  category: "CLASS_RANK" | "REPUTATION" | "ACHIEVEMENT" | "POLITICAL";
  grantedAt: number;       // tick
  grantedYear: number;
  active: boolean;
}

// ── Reputation thresholds → titles
export const REPUTATION_THRESHOLDS: Record<ReputationTrack, { threshold: number; title: string }[]> = {
  [ReputationTrack.HONOR]: [
    { threshold: 50, title: "Trusted" },
    { threshold: 100, title: "Honorable" },
    { threshold: 250, title: "Knight's Regard" },
    { threshold: 500, title: "Paragon" },
    { threshold: 800, title: "Living Legend" },
  ],
  [ReputationTrack.GUILD]: [
    { threshold: 50, title: "Recognized" },
    { threshold: 100, title: "Established" },
    { threshold: 250, title: "Master-Grade" },
    { threshold: 500, title: "Guild Pillar" },
    { threshold: 800, title: "Grand Master" },
  ],
  [ReputationTrack.SHADOW]: [
    { threshold: 50, title: "Known" },
    { threshold: 100, title: "Trusted (Shadow)" },
    { threshold: 250, title: "Inner Circle" },
    { threshold: 500, title: "Shadow Lieutenant" },
    { threshold: 800, title: "Shadow Master Candidate" },
  ],
  [ReputationTrack.CROWN]: [
    { threshold: 50, title: "Noted" },
    { threshold: 100, title: "Favored" },
    { threshold: 250, title: "Privy Counsel" },
    { threshold: 500, title: "Lord Protector" },
    { threshold: 800, title: "Regent Candidate" },
  ],
};

// ── Class starting conditions
export const CLASS_STARTING_CONDITIONS: Record<CharacterClass, { balance: number; rank: number }> = {
  [CharacterClass.PEASANT]:    { balance: 20,  rank: 1 },
  [CharacterClass.MERCHANT]:   { balance: 200, rank: 1 },
  [CharacterClass.ARTISAN]:    { balance: 80,  rank: 1 },
  [CharacterClass.KNIGHT]:     { balance: 150, rank: 1 },
  [CharacterClass.NOBLE]:      { balance: 400, rank: 1 },
  [CharacterClass.ROGUE]:      { balance: 60,  rank: 1 },
  [CharacterClass.MONK]:       { balance: 40,  rank: 1 },
  [CharacterClass.RANGER]:     { balance: 60,  rank: 1 },
  [CharacterClass.ADVENTURER]: { balance: 100, rank: 1 },
};

// ── Class rank titles
export const CLASS_RANK_TITLES: Record<CharacterClass, string[]> = {
  [CharacterClass.PEASANT]:    ["Peasant", "Freeholder", "Yeoman", "Steward", "Village Elder"],
  [CharacterClass.MERCHANT]:   ["Peddler", "Trader", "Merchant", "Master Merchant", "Consortium Elder"],
  [CharacterClass.ARTISAN]:    ["Apprentice", "Journeyman", "Craftsman", "Master Artisan", "Guild Master"],
  [CharacterClass.KNIGHT]:     ["Squire", "Man-at-Arms", "Knight", "Knight-Captain", "Knight-Commander"],
  [CharacterClass.NOBLE]:      ["Courtier", "Lord", "High Lord", "Councillor", "Regent"],
  [CharacterClass.ROGUE]:      ["Cutpurse", "Footpad", "Rogue", "Shadow Agent", "Shadow Master"],
  [CharacterClass.MONK]:       ["Novice", "Scholar", "Sage", "Lorekeeper", "Chancellor"],
  [CharacterClass.RANGER]:     ["Tracker", "Pathfinder", "Ranger", "Warden", "Grand Warden"],
  [CharacterClass.ADVENTURER]: ["Wanderer", "Adventurer", "Veteran", "Champion", "Legend"],
};

// ── Economy ──────────────────────────────────────────────────────
export enum TransactionType {
  LABOR_WAGE = "LABOR_WAGE",
  QUEST_REWARD = "QUEST_REWARD",
  MARKET_SELL = "MARKET_SELL",
  MARKET_BUY = "MARKET_BUY",
  TAX = "TAX",
  GUILD_DUES = "GUILD_DUES",
  FOOD_PURCHASE = "FOOD_PURCHASE",
  SETTLEMENT_MAINTENANCE = "SETTLEMENT_MAINTENANCE",
  FINE = "FINE",
  TRANSFER = "TRANSFER",
  INHERITANCE_DEPOSIT = "INHERITANCE_DEPOSIT",
  INHERITANCE_LOSS = "INHERITANCE_LOSS",
  STATUS_PURCHASE = "STATUS_PURCHASE",
  GAMBLING_LOSS = "GAMBLING_LOSS",
  SUBSIDY = "SUBSIDY",
}

export interface Transaction {
  type: TransactionType;
  fromId: CharacterId | "SYSTEM" | "NPC";
  toId: CharacterId | "SYSTEM" | "NPC";
  amount: number;          // always positive
  description: string;
  tick: number;
  year: number;
  season: Season;
}

// ── Guild ────────────────────────────────────────────────────────
export enum GuildStatus {
  PROPOSED = "PROPOSED",
  ACTIVE = "ACTIVE",
  PROBATION = "PROBATION",
  DISSOLVED = "DISSOLVED",
}

export enum GuildType {
  TRADE = "TRADE",
  SERVICE = "SERVICE",
  MILITARY = "MILITARY",
  CRIMINAL = "CRIMINAL",
  SCHOLARLY = "SCHOLARLY",
}

export interface Guild {
  id: GuildId;
  name: string;
  type: GuildType;
  status: GuildStatus;
  treasury: number;
  memberIds: CharacterId[];
  leaderId: CharacterId | null;
  homeSettlement: SettlementId | null;
  foundedYear: number;
  charterFee: number;
  monthlyDues: number;
  dissolvedAt: number | null;
}

// ── Settlement ───────────────────────────────────────────────────
export enum SettlementTier {
  UNCLAIMED = 0,
  CAMPSITE = 1,
  HAMLET = 2,
  VILLAGE = 3,
  TOWN = 4,
}

export interface Settlement {
  id: SettlementId;
  name: string;
  zone: ZoneId;
  tier: SettlementTier;
  population: number;
  residentIds: CharacterId[];
  founderId: HouseholdId;
  foundedYear: number;
  structures: string[];       // list of structure names
  condition: number;          // 0–100 (100 = perfect)
  elderId: CharacterId | null;
}

export const SETTLEMENT_TIER_REQUIREMENTS: Record<SettlementTier, { minPopulation: number; minStructures: number }> = {
  [SettlementTier.UNCLAIMED]: { minPopulation: 0, minStructures: 0 },
  [SettlementTier.CAMPSITE]:  { minPopulation: 1, minStructures: 0 },
  [SettlementTier.HAMLET]:    { minPopulation: 5, minStructures: 3 },
  [SettlementTier.VILLAGE]:   { minPopulation: 15, minStructures: 6 },
  [SettlementTier.TOWN]:      { minPopulation: 30, minStructures: 10 },
};

// ── Quest ────────────────────────────────────────────────────────
export enum QuestType {
  LABOR = "LABOR",
  DELIVERY = "DELIVERY",
  GATHERING = "GATHERING",
  COMBAT = "COMBAT",
  INVESTIGATION = "INVESTIGATION",
  POLITICAL = "POLITICAL",
}

export enum QuestStatus {
  AVAILABLE = "AVAILABLE",
  ACCEPTED = "ACCEPTED",
  COMPLETED = "COMPLETED",
  FAILED = "FAILED",
  EXPIRED = "EXPIRED",
}

export interface Quest {
  id: QuestId;
  type: QuestType;
  title: string;
  description: string;
  status: QuestStatus;
  assignedTo: CharacterId | null;
  rewardDeniers: number;
  rewardReputation: { track: ReputationTrack; amount: number } | null;
  significance: "MINOR" | "MAJOR";
  createdAt: number;       // tick
  expiresAt: number | null;
}

// ── Chronicle ────────────────────────────────────────────────────
export enum ChronicleSignificance {
  MINOR = "MINOR",
  MAJOR = "MAJOR",
  EPOCH = "EPOCH",
}

export interface ChronicleEntry {
  id: ChronicleEntryId;
  year: number;
  season: Season;
  day: number;
  title: string;
  description: string;
  significance: ChronicleSignificance;
  characterIds: CharacterId[];
  guildId: GuildId | null;
  settlementId: SettlementId | null;
  tags: string[];
  sealed: boolean;         // true after year-close
}

// ── Zone ─────────────────────────────────────────────────────────
export enum ZoneSafety {
  SAFE = "SAFE",
  MODERATE = "MODERATE",
  LOW = "LOW",
}

export interface Zone {
  id: ZoneId;
  name: string;
  inWorldName: string;
  ring: 0 | 1 | 2 | 3;
  safety: ZoneSafety;
  buildable: boolean;
}
