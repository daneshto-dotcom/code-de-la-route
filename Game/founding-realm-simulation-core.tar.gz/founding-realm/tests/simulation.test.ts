// ═══════════════════════════════════════════════════════════════════
// FOUNDING REALM — TEST SUITE
// Tests the simulation core without any I/O, networking, or UI.
// Run: npx ts-node tests/simulation.test.ts
// ═══════════════════════════════════════════════════════════════════

import { EventBus } from "../src/core/events";
import {
  createGameState, GameState, spawnCharacter, performLabor,
  earnReputation, doFoundSettlement, doCharterGuild,
  buyFood, payTax, doCompleteQuest, advanceDays, getEconomySnapshot,
  tick,
} from "../src/core/simulation";
import {
  createInitialClock, advanceTick, getPhaseForMinute,
  getSeasonForDay, getLifeStage, fastForwardDays,
} from "../src/modules/time";
import {
  processTransaction, createEconomyState, computeEconomySnapshot,
} from "../src/modules/economy";
import {
  createReputationScores, modifyReputation, getHighestTitle, totalReputation,
} from "../src/modules/reputation";
import { createHousehold, processInheritance, calculateHeritageBonus } from "../src/modules/household";
import { retireCharacter, killCharacter } from "../src/modules/character";
import { reviewSettlementTier, addResident, buildStructure } from "../src/modules/settlement";
import { getEntriesByYear, getEntriesByCharacter } from "../src/modules/chronicle";
import { seedRealm } from "../src/seed";
import {
  CharacterClass, CharacterId, HouseholdId, ReputationTrack,
  Season, DayPhase, TransactionType, SettlementTier, ZoneId,
  LifeStage, CharacterStatus, makeId,
} from "../src/types";

// ── Minimal test framework ───────────────────────────────────────
let passed = 0;
let failed = 0;
let currentSuite = "";

function suite(name: string) {
  currentSuite = name;
  console.log(`\n═══ ${name} ═══`);
}

function assert(condition: boolean, message: string) {
  if (condition) {
    passed++;
    console.log(`  ✓ ${message}`);
  } else {
    failed++;
    console.log(`  ✗ FAIL: ${message}`);
  }
}

function assertEqual<T>(actual: T, expected: T, message: string) {
  assert(actual === expected, `${message} (expected ${expected}, got ${actual})`);
}

function assertGreater(actual: number, expected: number, message: string) {
  assert(actual > expected, `${message} (expected > ${expected}, got ${actual})`);
}

function assertRange(actual: number, min: number, max: number, message: string) {
  assert(actual >= min && actual <= max, `${message} (expected ${min}–${max}, got ${actual})`);
}

// ═════════════════════════════════════════════════════════════════
// TEST SUITE 1: TIME MODULE
// ═════════════════════════════════════════════════════════════════
suite("TIME MODULE");

// Day phase determination
assertEqual(getPhaseForMinute(0), DayPhase.NIGHT, "Midnight is NIGHT");
assertEqual(getPhaseForMinute(300), DayPhase.DAWN, "5:00 is DAWN");
assertEqual(getPhaseForMinute(420), DayPhase.MORNING, "7:00 is MORNING");
assertEqual(getPhaseForMinute(720), DayPhase.MIDDAY, "12:00 is MIDDAY");
assertEqual(getPhaseForMinute(840), DayPhase.AFTERNOON, "14:00 is AFTERNOON");
assertEqual(getPhaseForMinute(1080), DayPhase.EVENING, "18:00 is EVENING");
assertEqual(getPhaseForMinute(1320), DayPhase.NIGHT, "22:00 is NIGHT");

// Season determination
assertEqual(getSeasonForDay(1), Season.SPRING, "Day 1 is SPRING");
assertEqual(getSeasonForDay(15), Season.SPRING, "Day 15 is SPRING");
assertEqual(getSeasonForDay(16), Season.SUMMER, "Day 16 is SUMMER");
assertEqual(getSeasonForDay(31), Season.AUTUMN, "Day 31 is AUTUMN");
assertEqual(getSeasonForDay(46), Season.WINTER, "Day 46 is WINTER");
assertEqual(getSeasonForDay(60), Season.WINTER, "Day 60 is WINTER");

// Life stage
assertEqual(getLifeStage(18), LifeStage.YOUTH, "Age 18 is YOUTH");
assertEqual(getLifeStage(25), LifeStage.YOUTH, "Age 25 is YOUTH");
assertEqual(getLifeStage(26), LifeStage.PRIME, "Age 26 is PRIME");
assertEqual(getLifeStage(45), LifeStage.PRIME, "Age 45 is PRIME");
assertEqual(getLifeStage(46), LifeStage.MATURITY, "Age 46 is MATURITY");
assertEqual(getLifeStage(61), LifeStage.ELDER, "Age 61 is ELDER");

// Clock advancement and events
(() => {
  const bus = new EventBus(true);
  let clock = createInitialClock(1601);
  let phaseChanges = 0;
  bus.on("time:dayPhaseChanged", () => { phaseChanges++; });

  // Advance through one full day (1440 game-minutes at 1 tick per minute)
  for (let i = 0; i < 1440; i++) {
    clock = advanceTick(clock, bus, 1);
  }
  assertEqual(clock.currentDay, 2, "After 1440 ticks (1 day), day advances to 2");
  assertGreater(phaseChanges, 0, "Day phase changed during a full day cycle");
})();

// Fast-forward through a full year
(() => {
  const bus = new EventBus(true);
  let yearChanged = false;
  let seasonChanges = 0;
  bus.on("time:yearChanged", () => { yearChanged = true; });
  bus.on("time:seasonChanged", () => { seasonChanges++; });

  const clock = fastForwardDays(createInitialClock(1601), bus, 60);

  assertEqual(clock.currentYear, 1602, "After 60 days, year advances to 1602");
  assertEqual(clock.currentDay, 1, "After year rollover, day resets to 1");
  assertEqual(clock.currentSeason, Season.SPRING, "New year starts in SPRING");
  assert(yearChanged, "YearChanged event fired");
  assertEqual(seasonChanges, 3, "3 mid-year season changes (SPRING→SUMMER→AUTUMN→WINTER; 4th happens at year boundary)");
})();

// ═════════════════════════════════════════════════════════════════
// TEST SUITE 2: ECONOMY MODULE
// ═════════════════════════════════════════════════════════════════
suite("ECONOMY MODULE");

// Basic transaction
(() => {
  const bus = new EventBus(true);
  const balances = new Map<CharacterId, number>();
  const charA = makeId<CharacterId>("chr");
  const charB = makeId<CharacterId>("chr");
  balances.set(charA, 100);
  balances.set(charB, 50);
  const econ = createEconomyState();

  const result = processTransaction(
    { type: TransactionType.TRANSFER, fromId: charA, toId: charB, amount: 30, description: "Trade" },
    balances, econ, bus, 1, 1601, Season.SPRING,
  );
  assert(result.success === true, "Transfer succeeds with sufficient funds");
  assertEqual(balances.get(charA)!, 70, "Sender balance decreased");
  assertEqual(balances.get(charB)!, 80, "Receiver balance increased");
  assertEqual(econ.transactionLog.length, 1, "Transaction logged");
  assertEqual(econ.dailyVolume, 30, "Daily volume updated");
})();

// Insufficient funds
(() => {
  const bus = new EventBus(true);
  const balances = new Map<CharacterId, number>();
  const charA = makeId<CharacterId>("chr");
  balances.set(charA, 10);
  const econ = createEconomyState();

  const result = processTransaction(
    { type: TransactionType.TRANSFER, fromId: charA, toId: "NPC", amount: 50, description: "Overcharge" },
    balances, econ, bus, 1, 1601, Season.SPRING,
  );
  assert(result.success === false, "Transfer fails with insufficient funds");
  assertEqual(balances.get(charA)!, 10, "Balance unchanged after failed transaction");
})();

// SYSTEM injection (infinite source)
(() => {
  const bus = new EventBus(true);
  const balances = new Map<CharacterId, number>();
  const charA = makeId<CharacterId>("chr");
  balances.set(charA, 0);
  const econ = createEconomyState();

  const result = processTransaction(
    { type: TransactionType.LABOR_WAGE, fromId: "SYSTEM", toId: charA, amount: 15, description: "Wage" },
    balances, econ, bus, 1, 1601, Season.SPRING,
  );
  assert(result.success === true, "SYSTEM injection always succeeds");
  assertEqual(balances.get(charA)!, 15, "Character received wage");
})();

// Economy health snapshot
(() => {
  const econ = createEconomyState();
  econ.totalMoneySupply = 1000;
  econ.dailyVolume = 350;
  const snapshot = computeEconomySnapshot(econ, 10);
  assertEqual(snapshot.averageWealth, 100, "Average wealth = supply / players");
  assertEqual(snapshot.velocity, 0.35, "Velocity = daily volume / supply");
  assertEqual(snapshot.inflationLevel, "GREEN", "Velocity 0.35 is GREEN");
})();

// ═════════════════════════════════════════════════════════════════
// TEST SUITE 3: REPUTATION & TITLES
// ═════════════════════════════════════════════════════════════════
suite("REPUTATION & TITLES");

// Basic reputation gain
(() => {
  const bus = new EventBus(true);
  const charId = makeId<CharacterId>("chr");
  const scores = createReputationScores();

  const { scores: updated } = modifyReputation(charId, scores, ReputationTrack.HONOR, 30, [], bus, 1, 1601);
  assertEqual(updated[ReputationTrack.HONOR], 30, "Honor increased by 30");
  assertEqual(updated[ReputationTrack.GUILD], 0, "Other tracks unchanged");
})();

// Reputation clamps to 0–999
(() => {
  const bus = new EventBus(true);
  const charId = makeId<CharacterId>("chr");
  let scores = createReputationScores();

  const { scores: s1 } = modifyReputation(charId, scores, ReputationTrack.HONOR, -50, [], bus, 1, 1601);
  assertEqual(s1[ReputationTrack.HONOR], 0, "Reputation cannot go below 0");

  scores = { ...createReputationScores(), [ReputationTrack.HONOR]: 990 };
  const { scores: s2 } = modifyReputation(charId, scores, ReputationTrack.HONOR, 50, [], bus, 1, 1601);
  assertEqual(s2[ReputationTrack.HONOR], 999, "Reputation cannot exceed 999");
})();

// Title threshold crossing
(() => {
  const bus = new EventBus(true);
  const charId = makeId<CharacterId>("chr");
  const scores = createReputationScores();

  // Jump past threshold (50 = "Trusted")
  const { scores: updated, newTitles } = modifyReputation(charId, scores, ReputationTrack.HONOR, 55, [], bus, 1, 1601);
  assertEqual(updated[ReputationTrack.HONOR], 55, "Honor is 55");
  assertEqual(newTitles.length, 1, "One title granted");
  assertEqual(newTitles[0].name, "Trusted", "Title is 'Trusted'");
  assertEqual(newTitles[0].category, "REPUTATION", "Title category is REPUTATION");

  // Cross second threshold (100 = "Honorable")
  const { newTitles: moreTitles } = modifyReputation(charId, updated, ReputationTrack.HONOR, 50, newTitles, bus, 2, 1601);
  assertEqual(moreTitles.length, 1, "Second title granted at 100");
  assertEqual(moreTitles[0].name, "Honorable", "Title is 'Honorable'");
})();

// Highest title lookup
(() => {
  const scores = { ...createReputationScores(), [ReputationTrack.GUILD]: 260 };
  const title = getHighestTitle(scores, ReputationTrack.GUILD);
  assertEqual(title, "Master-Grade", "260 Guild Standing = Master-Grade");
})();

// ═════════════════════════════════════════════════════════════════
// TEST SUITE 4: HOUSEHOLD & DYNASTY
// ═════════════════════════════════════════════════════════════════
suite("HOUSEHOLD & DYNASTY");

// Household creation
(() => {
  const bus = new EventBus(true);
  const hh = createHousehold("House Renard", 0, bus);
  assertEqual(hh.name, "House Renard", "Household name set");
  assertEqual(hh.generation, 1, "First generation");
  assertEqual(hh.treasury, 0, "Treasury starts at 0");
})();

// Inheritance processing
(() => {
  const bus = new EventBus(true);
  let hh = createHousehold("House Test", 0, bus);
  const charId = makeId<CharacterId>("chr");

  hh = processInheritance(hh, charId, 200, 150, bus, 100);
  assertEqual(hh.treasury, 100, "50% of 200d → 100d inherited");
  assertEqual(hh.generation, 2, "Generation advances");
  assertEqual(hh.reputationAggregate, 150, "Peak reputation added to aggregate");

  // Check event was fired
  const events = bus.getLogByEvent("household:inheritanceProcessed");
  assertEqual(events.length, 1, "Inheritance event fired");
})();

// Heritage bonus calculation
(() => {
  const bus = new EventBus(true);
  let hh = createHousehold("House Legacy", 0, bus);
  hh = { ...hh, treasury: 50, generation: 3, reputationAggregate: 600 };

  const bonus = calculateHeritageBonus(hh);
  assertEqual(bonus.wealthBonus, 50, "Wealth bonus = household treasury");
  assertGreater(bonus.reputationMultiplier, 1.0, "Reputation multiplier > 1.0 for established household");
  assertGreater(bonus.skillDiscount, 0, "Skill discount > 0 for multi-gen household");
})();

// Full dynasty cycle: create → earn → die → heir inherits
(() => {
  const { state, bus } = createGameState(1601);

  // Gen 1: Create character
  const charId = spawnCharacter(state, bus, "Founder", CharacterClass.PEASANT, "House Dynasty");
  const char = state.characters.get(charId as any)!;
  const hhId = char.householdId;

  // Earn some money and reputation
  performLabor(state, bus, charId as any, 50);
  earnReputation(state, bus, charId as any, ReputationTrack.HONOR, 60);

  const balanceBefore = state.balances.get(charId as any)!;
  assertGreater(balanceBefore, 50, "Character has earned money");

  // Die
  const dead = killCharacter(char, "test death", bus, state.clock.tickCount);
  state.characters.set(dead.id, dead);

  // Process inheritance
  const hh = state.households.get(hhId)!;
  const peakRep = totalReputation(state.reputations.get(charId as any)!);
  const updatedHh = processInheritance(hh, charId as any, balanceBefore, peakRep, bus, state.clock.tickCount);
  state.households.set(hhId, updatedHh);

  assertGreater(updatedHh.treasury, 0, "Household treasury received inheritance");
  assertEqual(updatedHh.generation, 2, "Generation advanced to 2");

  // Gen 2: Create heir
  const heirId = spawnCharacter(state, bus, "Heir", CharacterClass.KNIGHT, "House Dynasty");
  const heir = state.characters.get(heirId as any)!;
  assertEqual(heir.householdId, hhId, "Heir belongs to same household");
  assertGreater(heir.balance, 150, "Heir received heritage wealth bonus on top of Knight starting balance");

  assert(true, "Full dynasty cycle completed successfully");
})();

// ═════════════════════════════════════════════════════════════════
// TEST SUITE 5: SETTLEMENTS
// ═════════════════════════════════════════════════════════════════
suite("SETTLEMENTS");

// Settlement founding and tier review
(() => {
  const { state, bus } = createGameState(1601);

  // Found a settlement
  const charId = spawnCharacter(state, bus, "Settler", CharacterClass.PEASANT, "House Settler");
  const stlId = doFoundSettlement(state, bus, "Testwood", "zone_ashwood" as ZoneId, charId as any);
  assert(stlId !== null, "Settlement founded");

  let stl = state.settlements.get(stlId!)!;
  assertEqual(stl.tier, SettlementTier.CAMPSITE, "Initial tier is CAMPSITE");
  assertRange(stl.population, 1, 2, "Population includes founder");

  // Add residents to reach Hamlet (need 5+ pop, 3+ structures)
  for (let i = 0; i < 5; i++) {
    const resId = spawnCharacter(state, bus, `Resident ${i}`, CharacterClass.PEASANT, `House R${i}`);
    stl = addResident(stl, resId as any);
  }
  stl = buildStructure(stl, "Well", state.clock.tickCount, bus);
  stl = buildStructure(stl, "Workshop", state.clock.tickCount, bus);
  stl = buildStructure(stl, "Fire Pit", state.clock.tickCount, bus);
  state.settlements.set(stlId!, stl);

  // Review tier
  stl = reviewSettlementTier(stl, state.clock.tickCount, bus);
  assertEqual(stl.tier, SettlementTier.HAMLET, "Settlement advanced to HAMLET with 6 pop + 3 structures");

  // Check Chronicle recorded the tier change
  const tierEvents = bus.getLogByEvent("settlement:tierChanged");
  assertGreater(tierEvents.length, 0, "Settlement tier change event fired");
})();

// ═════════════════════════════════════════════════════════════════
// TEST SUITE 6: GUILDS
// ═════════════════════════════════════════════════════════════════
suite("GUILDS");

(() => {
  const { state, bus } = createGameState(1601);

  const founder = spawnCharacter(state, bus, "Guildmaster", CharacterClass.ARTISAN, "House GM");
  const member1 = spawnCharacter(state, bus, "Member 1", CharacterClass.ARTISAN, "House M1");
  const member2 = spawnCharacter(state, bus, "Member 2", CharacterClass.ARTISAN, "House M2");

  const guildId = doCharterGuild(state, bus, "Weavers Guild", "TRADE", founder as any);
  assert(guildId !== null, "Guild chartered");

  let guild = state.guilds.get(guildId!)!;
  assertEqual(guild.status, "ACTIVE", "Guild is ACTIVE");
  assertEqual(guild.memberIds.length, 1, "Guild has 1 member (founder)");

  // Check charter event in Chronicle
  const charteredEvents = bus.getLogByEvent("guild:chartered");
  assertEqual(charteredEvents.length, 1, "Guild chartered event fired");
})();

// ═════════════════════════════════════════════════════════════════
// TEST SUITE 7: CHRONICLE
// ═════════════════════════════════════════════════════════════════
suite("CHRONICLE");

(() => {
  const { state, bus } = createGameState(1601);

  // Spawn characters and do notable things
  const charId = spawnCharacter(state, bus, "Hero", CharacterClass.KNIGHT, "House Hero");
  doFoundSettlement(state, bus, "Herostead", "zone_ashwood" as ZoneId, charId as any);
  doCharterGuild(state, bus, "Heroes Guild", "MILITARY", charId as any);
  earnReputation(state, bus, charId as any, ReputationTrack.HONOR, 55); // crosses "Trusted" threshold

  const entries = state.chronicle.entries;
  assertGreater(entries.length, 0, "Chronicle has entries");

  // Check different entry types exist
  const tags = entries.flatMap(e => e.tags);
  assert(tags.includes("settlement"), "Chronicle contains settlement entries");
  assert(tags.includes("guild"), "Chronicle contains guild entries");
  assert(tags.includes("title"), "Chronicle contains title entries");

  // Year seal test
  advanceDays(state, bus, 60); // advance through full year
  const sealedEntries = state.chronicle.entries.filter(e => e.sealed && e.year === 1601);
  assertGreater(sealedEntries.length, 0, "Year 1601 entries are sealed after year-close");

  const sealEvents = bus.getLogByEvent("chronicle:yearSealed");
  assertGreater(sealEvents.length, 0, "Year sealed event fired");
})();

// ═════════════════════════════════════════════════════════════════
// TEST SUITE 8: FULL SEED SCENARIO
// ═════════════════════════════════════════════════════════════════
suite("FULL SEED SCENARIO");

(() => {
  console.log("  Seeding realm...");
  const { state, bus, characterIds } = seedRealm();

  assertGreater(state.characters.size, 10, "12+ characters created");
  assertGreater(state.settlements.size, 0, "Settlements exist");
  assertGreater(state.guilds.size, 0, "Guilds exist");
  assertGreater(state.chronicle.entries.length, 0, "Chronicle has entries");
  assertGreater(state.economy.transactionLog.length, 0, "Transactions occurred");
  assertGreater(state.titles.length, 0, "Titles were granted");

  const snapshot = getEconomySnapshot(state);
  assertGreater(snapshot.moneySupply, 0, "Money supply is positive");
  assertEqual(snapshot.inflationLevel, "GREEN", "Economy is healthy (GREEN)");

  // Verify class diversity
  const classes = new Set(Array.from(state.characters.values()).map(c => c.class));
  assertGreater(classes.size, 7, "8+ distinct classes represented");

  // Verify Brennan earned "Trusted" title
  const brennanTitles = state.titles.filter(t => t.characterId === characterIds.brennan);
  assertGreater(brennanTitles.length, 0, "Brennan (Knight) earned at least one title");

  console.log("\n  Advancing 15 game-days (one season)...");
  advanceDays(state, bus, 15);
  assertEqual(state.clock.currentSeason, Season.SUMMER, "Season advanced to SUMMER after 15 days");

  console.log("  Advancing full year...");
  advanceDays(state, bus, 45); // remaining days to complete year
  assertEqual(state.clock.currentYear, 1602, "Year advanced to 1602");

  const year1Entries = getEntriesByYear(state.chronicle, 1601);
  assertGreater(year1Entries.length, 0, "Year 1601 has Chronicle entries");
  const sealed1601 = year1Entries.filter(e => e.sealed);
  assertGreater(sealed1601.length, 0, "Most Year 1601 entries are sealed");

  assert(true, "Full seed scenario completed successfully");
})();

// ═════════════════════════════════════════════════════════════════
// TEST SUITE 9: QUEST SYSTEM
// ═════════════════════════════════════════════════════════════════
suite("QUEST SYSTEM");

(() => {
  const { state, bus } = createGameState(1601);
  const charId = spawnCharacter(state, bus, "Quester", CharacterClass.ADVENTURER, "House Q");

  // Generate quests
  const { generateDailyQuests } = require("../src/modules/quest");
  const quests = generateDailyQuests(0, 5);
  assertEqual(quests.length, 5, "5 daily quests generated");
  assert(quests.every((q: any) => q.status === "AVAILABLE"), "All quests start AVAILABLE");

  // Complete a quest
  state.quests = quests;
  const balanceBefore = state.balances.get(charId as any)!;
  const success = doCompleteQuest(state, bus, quests[0].id, charId as any);
  assert(success, "Quest completed successfully");
  assertGreater(state.balances.get(charId as any)!, balanceBefore, "Balance increased from quest reward");

  const completedEvents = bus.getLogByEvent("quest:completed");
  assertEqual(completedEvents.length, 1, "Quest completed event fired");
})();

// ═════════════════════════════════════════════════════════════════
// RESULTS
// ═════════════════════════════════════════════════════════════════
console.log("\n═══════════════════════════════════════════════════");
console.log(`  RESULTS: ${passed} passed, ${failed} failed, ${passed + failed} total`);
console.log("═══════════════════════════════════════════════════");

if (failed > 0) {
  console.log("\n  ⚠ SOME TESTS FAILED — review output above.");
  process.exit(1);
} else {
  console.log("\n  ✓ ALL TESTS PASSED — simulation core is sound.");
  process.exit(0);
}
